import SEO from "../components/SEO";
import Reveal from "../components/Reveal";
import { site } from "../config/site";

const sections: { h: string; p: string[] }[] = [
  {
    h: "1. Information We Collect",
    p: [
      "When you use AstroVeda, we collect information you voluntarily provide: your name, email address, phone number, and — for astrological services — your date, time and place of birth. For paid services, payment is processed by Razorpay; we never see or store your card, UPI or banking credentials.",
      "We may also collect basic usage data (pages visited, device type) to improve the website experience."
    ]
  },
  {
    h: "2. How We Use Your Information",
    p: [
      "Birth details are used solely to prepare your kundli, numerology or Vastu analysis. Contact details are used to deliver reports, confirm bookings, send invoices, and respond to your enquiries.",
      "With your consent, we may occasionally share remedies, transit alerts or offers. You can opt out of these at any time by replying \"STOP\" or emailing us."
    ]
  },
  {
    h: "3. Confidentiality of Consultations",
    p: [
      "Everything discussed in a consultation — your chart, questions, and personal circumstances — is treated as strictly confidential. We do not share, sell or rent your personal information or birth data to any third party for marketing purposes."
    ]
  },
  {
    h: "4. Data Storage & Security",
    p: [
      "Your data is stored on secure, access-controlled infrastructure (Google Firebase) with encryption in transit. Access is restricted to authorised AstroVeda staff who need it to serve you.",
      "While we follow industry-standard safeguards, no online transmission is 100% secure; you share information at your own discretion."
    ]
  },
  {
    h: "5. Payments",
    p: [
      "All payments are handled by Razorpay, a PCI-DSS compliant payment gateway. Refer to Razorpay's privacy policy for how they handle transaction data. We retain only your invoice details (name, amount, payment ID) for accounting and legal compliance."
    ]
  },
  {
    h: "6. Cookies",
    p: [
      "We use minimal cookies and browser storage strictly for site functionality (e.g., remembering your kundli inputs on your own device). We do not use third-party advertising trackers."
    ]
  },
  {
    h: "7. Your Rights",
    p: [
      "You may request a copy of the personal data we hold about you, ask us to correct it, or ask us to delete it entirely. Write to us at the email below and we will act within 7 working days."
    ]
  },
  {
    h: "8. Children's Privacy",
    p: [
      "Our services are intended for individuals 18 years and older. Kundli services for minors must be requested by a parent or legal guardian."
    ]
  },
  {
    h: "9. Changes to This Policy",
    p: [
      "We may update this policy from time to time. The latest version will always be available on this page with the revision date below."
    ]
  }
];

export default function Privacy() {
  return (
    <main className="bg-gradient-to-b from-royal-50 to-white pt-28 pb-24">
      <SEO
        title="Privacy Policy"
        description="How AstroVeda collects, uses and protects your personal information and birth details."
      />
      <div className="mx-auto max-w-3xl px-4">
        <Reveal>
          <p className="eyebrow">Legal</p>
          <h1 className="font-display text-4xl text-ink mt-3">Privacy Policy</h1>
          <p className="mt-3 text-sm text-ink/55">Last updated: 1 June 2026</p>
          <p className="mt-6 text-ink/75 leading-7">
            At {site.name}, your trust is sacred to us. This policy explains what information we
            collect, why we collect it, and how we keep it safe.
          </p>
        </Reveal>

        <div className="mt-10 space-y-8">
          {sections.map((s, i) => (
            <Reveal key={s.h} delay={Math.min(i * 0.04, 0.2)}>
              <h2 className="font-display text-xl text-ink">{s.h}</h2>
              {s.p.map((para, j) => (
                <p key={j} className="mt-2 text-ink/75 leading-7 text-[0.97rem]">{para}</p>
              ))}
            </Reveal>
          ))}
        </div>

        <Reveal delay={0.1} className="mt-12 rounded-2xl bg-royal-50 border border-royal-100 p-6 text-sm text-ink/75">
          Questions about your data? Email{" "}
          <a href={`mailto:${site.email}`} className="text-royal-700 font-semibold hover:underline">{site.email}</a>{" "}
          or write to us at {site.address}.
        </Reveal>
      </div>
    </main>
  );
}
