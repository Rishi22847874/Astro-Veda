import { Link, useLocation, Navigate } from "react-router-dom";
import { motion } from "framer-motion";
import SEO from "../components/SEO";
import { downloadInvoicePdf, type InvoiceData } from "../lib/pdf";
import { whatsappLink } from "../lib/whatsapp";

export default function PaymentSuccess() {
  const { state } = useLocation() as { state?: { invoice?: InvoiceData; demo?: boolean } };
  const invoice = state?.invoice;

  if (!invoice) return <Navigate to="/pricing" replace />;

  return (
    <main className="min-h-[80vh] bg-gradient-to-b from-royal-50 to-white pt-32 pb-24">
      <SEO title="Payment Successful" description="Your AstroVeda consultation payment was successful." />
      <div className="mx-auto max-w-xl px-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.92, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          transition={{ duration: 0.5, ease: [0.21, 0.6, 0.35, 1] }}
          className="glass rounded-3xl border border-royal-100 p-8 text-center"
        >
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.25, type: "spring", stiffness: 200, damping: 12 }}
            className="mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-green-100 text-4xl"
          >
            ✅
          </motion.div>
          <h1 className="font-display text-3xl text-ink mt-5">Payment successful!</h1>
          <p className="mt-2 text-ink/70">
            Thank you, {invoice.customerName}. Your <strong>{invoice.packageName}</strong> is confirmed.
            Our astrologer will contact you within 24 hours to schedule your session.
          </p>

          {state?.demo && (
            <p className="mt-3 rounded-xl bg-gold-50 border border-gold-200 px-4 py-2 text-xs text-ink/70">
              Demo mode: no real money was charged. Add your Razorpay key in <code>.env</code> to enable live payments.
            </p>
          )}

          <div className="mt-6 rounded-2xl bg-royal-50 p-5 text-left text-sm space-y-2">
            <Row label="Invoice no." value={invoice.invoiceNo} />
            <Row label="Payment ID" value={invoice.paymentId} />
            <Row label="Amount paid" value={`₹${invoice.amount.toLocaleString("en-IN")}`} />
            <Row label="Date" value={invoice.date} />
          </div>

          <div className="mt-7 flex flex-col sm:flex-row gap-3 justify-center">
            <button onClick={() => downloadInvoicePdf(invoice)} className="btn-gold">
              ⬇ Download Invoice (PDF)
            </button>
            <a
              href={whatsappLink(`Hi! I just purchased the ${invoice.packageName} (Invoice ${invoice.invoiceNo}). When can we schedule my session?`)}
              target="_blank"
              rel="noreferrer"
              className="btn-ghost"
            >
              Schedule on WhatsApp
            </a>
          </div>

          <Link to="/" className="mt-6 inline-block text-sm text-royal-700 hover:underline underline-offset-4">
            ← Back to home
          </Link>
        </motion.div>
      </div>
    </main>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between gap-4">
      <span className="text-ink/55">{label}</span>
      <span className="font-semibold text-ink">{value}</span>
    </div>
  );
}
