/**
 * Data layer for leads, bookings, payments and contact messages.
 * Uses Firestore when Firebase env vars are set; otherwise falls back to
 * localStorage so the whole app works end-to-end out of the box.
 */
import { db, firebaseEnabled } from "./firebase";
import { addDoc, collection, getDocs, orderBy, query } from "firebase/firestore";

export type CollectionName = "leads" | "bookings" | "payments" | "messages";

export interface StoredRecord {
  id: string;
  createdAt: string;
  [key: string]: any;
}

const LS_PREFIX = "astroveda_";

function lsRead(name: CollectionName): StoredRecord[] {
  try {
    return JSON.parse(localStorage.getItem(LS_PREFIX + name) || "[]");
  } catch {
    return [];
  }
}

function lsWrite(name: CollectionName, rows: StoredRecord[]) {
  localStorage.setItem(LS_PREFIX + name, JSON.stringify(rows));
}

export async function saveRecord(name: CollectionName, data: Record<string, any>): Promise<StoredRecord> {
  const record: StoredRecord = {
    id: crypto.randomUUID(),
    createdAt: new Date().toISOString(),
    ...data
  };
  if (firebaseEnabled && db) {
    try {
      const ref = await addDoc(collection(db, name), record);
      return { ...record, id: ref.id };
    } catch (e) {
      console.error("Firestore write failed, falling back to localStorage", e);
    }
  }
  const rows = lsRead(name);
  rows.unshift(record);
  lsWrite(name, rows);
  return record;
}

export async function listRecords(name: CollectionName): Promise<StoredRecord[]> {
  if (firebaseEnabled && db) {
    try {
      const snap = await getDocs(query(collection(db, name), orderBy("createdAt", "desc")));
      return snap.docs.map((d) => ({ ...(d.data() as any), id: d.id }));
    } catch (e) {
      console.error("Firestore read failed, falling back to localStorage", e);
    }
  }
  return lsRead(name);
}
