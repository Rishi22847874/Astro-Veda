import { useState } from "react";
import SEO from "./SEO";
import Reveal from "./Reveal";
import ServiceCard from "./ServiceCard";
import { InquiryDialog, InquiryForm } from "./InquiryForm";
import type { ServiceItem } from "../data/services";

interface Props {
  seoTitle: string;
  seoDescription: string;
  eyebrow: string;
  title: string;
  intro: string;
  items: ServiceItem[];
  source: string;
}

export default function ServicePageLayout({ seoTitle, seoDescription, eyebrow, title, intro, items, source }: Props) {
  const [selected, setSelected] = useState<ServiceItem | null>(null);
  const serviceNames = items.map((i) => i.title);

  return (
    <main>
      <SEO title={seoTitle} description={seoDescription} />
      <section className="mx-auto max-w-7xl px-4 pb-4 pt-14 sm:px-6">
        <Reveal>
          <p className="eyebrow">{eyebrow}</p>
          <h1 className="h-display mt-2 max-w-3xl text-4xl sm:text-5xl">{title}</h1>
          <p className="mt-4 max-w-2xl text-ink/70">{intro}</p>
        </Reveal>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {items.map((item, i) => (
            <Reveal key={item.slug} delay={Math.min(i * 0.05, 0.3)}>
              <ServiceCard item={item} onInquire={setSelected} />
            </Reveal>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-4xl px-4 py-12 sm:px-6">
        <Reveal>
          <div className="glass p-6 sm:p-10">
            <p className="eyebrow">Quick enquiry</p>
            <h2 className="h-display mt-1 text-3xl">Not sure which service fits? Ask us.</h2>
            <p className="mb-6 mt-2 text-sm text-ink/70">
              Share your situation and a consultant will recommend the right reading — no obligation.
            </p>
            <InquiryForm source={source} services={serviceNames} />
          </div>
        </Reveal>
      </section>

      <InquiryDialog
        open={!!selected}
        onClose={() => setSelected(null)}
        source={source}
        services={serviceNames}
        defaultService={selected?.title}
      />
    </main>
  );
}
