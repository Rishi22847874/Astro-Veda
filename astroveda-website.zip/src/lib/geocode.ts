/** Lightweight city → lat/lon lookup for Kundli generation (major Indian + world cities). */
export interface GeoPoint { lat: number; lon: number; tz: number; }

const CITIES: Record<string, GeoPoint> = {
  delhi: { lat: 28.6139, lon: 77.209, tz: 5.5 },
  "new delhi": { lat: 28.6139, lon: 77.209, tz: 5.5 },
  mumbai: { lat: 19.076, lon: 72.8777, tz: 5.5 },
  kolkata: { lat: 22.5726, lon: 88.3639, tz: 5.5 },
  chennai: { lat: 13.0827, lon: 80.2707, tz: 5.5 },
  bengaluru: { lat: 12.9716, lon: 77.5946, tz: 5.5 },
  bangalore: { lat: 12.9716, lon: 77.5946, tz: 5.5 },
  hyderabad: { lat: 17.385, lon: 78.4867, tz: 5.5 },
  pune: { lat: 18.5204, lon: 73.8567, tz: 5.5 },
  ahmedabad: { lat: 23.0225, lon: 72.5714, tz: 5.5 },
  jaipur: { lat: 26.9124, lon: 75.7873, tz: 5.5 },
  lucknow: { lat: 26.8467, lon: 80.9462, tz: 5.5 },
  chandigarh: { lat: 30.7333, lon: 76.7794, tz: 5.5 },
  varanasi: { lat: 25.3176, lon: 82.9739, tz: 5.5 },
  patna: { lat: 25.5941, lon: 85.1376, tz: 5.5 },
  bhopal: { lat: 23.2599, lon: 77.4126, tz: 5.5 },
  indore: { lat: 22.7196, lon: 75.8577, tz: 5.5 },
  nagpur: { lat: 21.1458, lon: 79.0882, tz: 5.5 },
  surat: { lat: 21.1702, lon: 72.8311, tz: 5.5 },
  kanpur: { lat: 26.4499, lon: 80.3319, tz: 5.5 },
  guwahati: { lat: 26.1445, lon: 91.7362, tz: 5.5 },
  kochi: { lat: 9.9312, lon: 76.2673, tz: 5.5 },
  london: { lat: 51.5074, lon: -0.1278, tz: 0 },
  "new york": { lat: 40.7128, lon: -74.006, tz: -5 },
  dubai: { lat: 25.2048, lon: 55.2708, tz: 4 },
  singapore: { lat: 1.3521, lon: 103.8198, tz: 8 },
  toronto: { lat: 43.6532, lon: -79.3832, tz: -5 },
  sydney: { lat: -33.8688, lon: 151.2093, tz: 10 }
};

export function geocodePlace(place: string): GeoPoint {
  const key = place.toLowerCase().trim();
  for (const name of Object.keys(CITIES)) {
    if (key.includes(name)) return CITIES[name];
  }
  return CITIES.delhi; // sensible Indian default
}
