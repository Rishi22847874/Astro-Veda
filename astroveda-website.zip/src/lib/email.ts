/**
 * EmailJS wrapper. Sends a copy to the visitor and a notification to the admin.
 * Safe no-op (resolves false) when EmailJS env vars are not configured.
 */
import emailjs from "@emailjs/browser";

const SERVICE = import.meta.env.VITE_EMAILJS_SERVICE_ID || "";
const PUBLIC_KEY = import.meta.env.VITE_EMAILJS_PUBLIC_KEY || "";
const TPL_USER = import.meta.env.VITE_EMAILJS_TEMPLATE_USER || "";
const TPL_ADMIN = import.meta.env.VITE_EMAILJS_TEMPLATE_ADMIN || "";

export const emailEnabled = Boolean(SERVICE && PUBLIC_KEY);

if (emailEnabled) emailjs.init({ publicKey: PUBLIC_KEY });

async function send(template: string, params: Record<string, any>): Promise<boolean> {
  if (!emailEnabled || !template) return false;
  try {
    await emailjs.send(SERVICE, template, params);
    return true;
  } catch (e) {
    console.error("EmailJS send failed", e);
    return false;
  }
}

/** Email the visitor (confirmation / report / invoice summary). */
export function emailUser(params: { to_email: string; to_name: string; subject: string; message: string }) {
  return send(TPL_USER, params);
}

/** Notify the admin about a new lead / booking / payment / message. */
export function emailAdmin(params: { subject: string; message: string }) {
  return send(TPL_ADMIN, params);
}
