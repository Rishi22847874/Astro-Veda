import { motion } from "framer-motion";
import type { ServiceItem } from "../data/services";

export default function ServiceCard({
  item,
  onInquire
}: {
  item: ServiceItem;
  onInquire: (item: ServiceItem) => void;
}) {
  return (
    <motion.article
      whileHover={{ y: -6 }}
      transition={{ type: "spring", stiffness: 300, damping: 22 }}
      className="glass flex flex-col p-6"
    >
      <span className="text-3xl" aria-hidden>{item.icon}</span>
      <h3 className="h-display mt-3 text-xl">{item.title}</h3>
      <p className="mt-2 flex-1 text-sm text-ink/70">{item.description}</p>
      <button className="btn-ghost mt-5 !px-4 !py-2 text-sm" onClick={() => onInquire(item)}>
        Enquire now
      </button>
    </motion.article>
  );
}
