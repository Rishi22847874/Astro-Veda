import ServicePageLayout from "../components/ServicePageLayout";
import { vastuServices } from "../data/services";

export default function Vastu() {
  return (
    <ServicePageLayout
      seoTitle="Vastu Services"
      seoDescription="Home Vastu, office Vastu, commercial and factory Vastu audits, and plot selection — practical, no-demolition remedies by a qualified Vastu architect."
      eyebrow="Vastu Shastra · The science of space"
      title="Vastu Services"
      intro="Spaces shape moods, money and momentum. Our audits are led by a qualified architect and favour rearrangement over renovation — most homes need zero demolition."
      items={vastuServices}
      source="vastu"
    />
  );
}
