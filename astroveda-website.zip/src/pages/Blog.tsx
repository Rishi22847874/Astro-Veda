import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { Pagination } from "@mui/material";
import SEO from "../components/SEO";
import Reveal from "../components/Reveal";
import { blogPosts, categories } from "../data/blog";

const PER_PAGE = 6;

export default function Blog() {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState<(typeof categories)[number]>("All");
  const [page, setPage] = useState(1);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return blogPosts.filter((p) => {
      const matchCat = category === "All" || p.category === category;
      const matchQ =
        !q ||
        p.title.toLowerCase().includes(q) ||
        p.excerpt.toLowerCase().includes(q) ||
        p.category.toLowerCase().includes(q);
      return matchCat && matchQ;
    });
  }, [query, category]);

  const pageCount = Math.max(1, Math.ceil(filtered.length / PER_PAGE));
  const visible = filtered.slice((page - 1) * PER_PAGE, page * PER_PAGE);

  return (
    <main>
      <SEO
        title="Blog — Astrology, Numerology & Vastu Insights"
        description="Articles on Vedic astrology, numerology and Vastu Shastra: remedies, planetary transits, name corrections and home harmony tips from AstroVeda."
      />

      <section className="bg-gradient-to-b from-royal-50 to-white pt-28 pb-12">
        <div className="mx-auto max-w-6xl px-4 text-center">
          <Reveal>
            <p className="eyebrow">Wisdom Journal</p>
            <h1 className="font-display text-4xl md:text-5xl text-ink mt-3">
              Cosmic <span className="text-royal-700">insights</span>, written for everyday life
            </h1>
          </Reveal>

          <Reveal delay={0.1} className="mt-8 max-w-xl mx-auto">
            <input
              type="search"
              value={query}
              onChange={(e) => { setQuery(e.target.value); setPage(1); }}
              placeholder="Search articles… e.g. Saturn, name correction, kitchen Vastu"
              className="input-base w-full"
              aria-label="Search blog articles"
            />
          </Reveal>

          <Reveal delay={0.15} className="mt-5 flex flex-wrap justify-center gap-2">
            {categories.map((c) => (
              <button
                key={c}
                onClick={() => { setCategory(c); setPage(1); }}
                className={`rounded-full px-5 py-2 text-sm font-semibold transition-colors ${
                  category === c
                    ? "bg-royal-800 text-white"
                    : "bg-white border border-royal-200 text-royal-800 hover:bg-royal-50"
                }`}
              >
                {c}
              </button>
            ))}
          </Reveal>
        </div>
      </section>

      <section className="pb-24">
        <div className="mx-auto max-w-6xl px-4">
          {visible.length === 0 ? (
            <div className="text-center py-20 text-ink/60">
              <div className="text-5xl mb-4">🔭</div>
              <p className="font-display text-2xl text-ink">No articles found</p>
              <p className="mt-2 text-sm">Try a different keyword or category.</p>
            </div>
          ) : (
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {visible.map((post, i) => (
                <Reveal key={post.slug} delay={i * 0.06}>
                  <Link
                    to={`/blog/${post.slug}`}
                    className="group block h-full glass rounded-3xl border border-royal-100 p-7 transition-shadow hover:shadow-xl"
                  >
                    <div className="flex items-center justify-between">
                      <span className="rounded-full bg-royal-50 px-3 py-1 text-xs font-semibold text-royal-800">
                        {post.category}
                      </span>
                      <span className="text-3xl">{post.emoji}</span>
                    </div>
                    <h2 className="mt-4 font-display text-xl text-ink group-hover:text-royal-700 transition-colors">
                      {post.title}
                    </h2>
                    <p className="mt-2 text-sm text-ink/65 line-clamp-3">{post.excerpt}</p>
                    <div className="mt-5 flex items-center justify-between text-xs text-ink/50">
                      <span>{post.date}</span>
                      <span>{post.readMins} min read</span>
                    </div>
                  </Link>
                </Reveal>
              ))}
            </div>
          )}

          {pageCount > 1 && (
            <div className="mt-12 flex justify-center">
              <Pagination
                count={pageCount}
                page={page}
                onChange={(_, v) => { setPage(v); window.scrollTo({ top: 0, behavior: "smooth" }); }}
                color="primary"
                shape="rounded"
              />
            </div>
          )}
        </div>
      </section>
    </main>
  );
}
