/**
 * Razorpay Checkout integration.
 * Loads checkout.js on demand. When VITE_RAZORPAY_KEY_ID is not set, runs a
 * clearly-labelled demo flow so the full purchase → invoice → email pipeline
 * can be exercised locally without keys.
 */
import { site } from "../config/site";

let scriptPromise: Promise<boolean> | null = null;

export function loadRazorpay(): Promise<boolean> {
  if (window.Razorpay) return Promise.resolve(true);
  if (scriptPromise) return scriptPromise;
  scriptPromise = new Promise((resolve) => {
    const s = document.createElement("script");
    s.src = "https://checkout.razorpay.com/v1/checkout.js";
    s.onload = () => resolve(true);
    s.onerror = () => resolve(false);
    document.body.appendChild(s);
  });
  return scriptPromise;
}

export interface CheckoutOptions {
  amount: number; // INR rupees
  description: string;
  name: string;
  email: string;
  phone: string;
}

export interface PaymentResult {
  success: boolean;
  paymentId: string;
  demo: boolean;
  error?: string;
}

export async function openCheckout(opts: CheckoutOptions): Promise<PaymentResult> {
  if (!site.razorpayKey) {
    // Demo mode: simulate a successful capture so downstream flows work.
    await new Promise((r) => setTimeout(r, 900));
    return { success: true, paymentId: "demo_" + Date.now().toString(36), demo: true };
  }

  const loaded = await loadRazorpay();
  if (!loaded || !window.Razorpay) {
    return { success: false, paymentId: "", demo: false, error: "Razorpay failed to load. Check your connection." };
  }

  return new Promise<PaymentResult>((resolve) => {
    const rzp = new window.Razorpay({
      key: site.razorpayKey,
      amount: Math.round(opts.amount * 100),
      currency: "INR",
      name: site.name,
      description: opts.description,
      prefill: { name: opts.name, email: opts.email, contact: opts.phone },
      theme: { color: "#4527A0" },
      handler: (res: any) =>
        resolve({ success: true, paymentId: res.razorpay_payment_id, demo: false }),
      modal: {
        ondismiss: () =>
          resolve({ success: false, paymentId: "", demo: false, error: "Payment was cancelled." })
      }
    });
    rzp.on("payment.failed", (res: any) =>
      resolve({ success: false, paymentId: "", demo: false, error: res?.error?.description || "Payment failed." })
    );
    rzp.open();
  });
}
