import ServicePageLayout from "../components/ServicePageLayout";
import { astrologyServices } from "../data/services";

export default function Astrology() {
  return (
    <ServicePageLayout
      seoTitle="Astrology Services"
      seoDescription="Birth chart analysis, daily/weekly/yearly horoscopes, career and business guidance, marriage compatibility, transit and dasha analysis, gemstone recommendations."
      eyebrow="Jyotish · The science of light"
      title="Astrology Services"
      intro="From a complete Janma Kundli reading to precise dasha timelines, every consultation is computed sidereally and interpreted by a senior astrologer — never by a script."
      items={astrologyServices}
      source="astrology"
    />
  );
}
