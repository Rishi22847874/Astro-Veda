export interface PricingPackage {
  id: string;
  name: string;
  price: number;
  tagline: string;
  features: string[];
  popular?: boolean;
}

export const packages: PricingPackage[] = [
  {
    id: "basic",
    name: "Basic Report",
    price: 499,
    tagline: "Your essential Vedic snapshot",
    features: [
      "Janma Kundli with planetary positions",
      "Moon sign, Lagna & Nakshatra analysis",
      "Lucky numbers, colours & gemstone",
      "10-page PDF report by email",
      "Delivery within 24 hours"
    ]
  },
  {
    id: "premium",
    name: "Premium Report",
    price: 1499,
    tagline: "Deep-dive into every house",
    popular: true,
    features: [
      "Everything in Basic Report",
      "House-by-house life analysis",
      "Vimshottari Dasha predictions (20 yrs)",
      "Career, wealth & health forecast",
      "Personalised remedies & mantras",
      "30-min follow-up call with astrologer"
    ]
  },
  {
    id: "business",
    name: "Business Report",
    price: 2499,
    tagline: "For founders & professionals",
    features: [
      "Business aptitude from your chart",
      "Best industries & partnership analysis",
      "Numerology-corrected brand name",
      "Launch muhurta for next 12 months",
      "Office Vastu quick-check",
      "45-min strategy consultation"
    ]
  },
  {
    id: "marriage",
    name: "Marriage Report",
    price: 1999,
    tagline: "Compatibility, decoded",
    features: [
      "Ashtakoota Guna Milan (36 points)",
      "Mangal dosha check for both charts",
      "Emotional & financial compatibility",
      "Favourable marriage muhurta windows",
      "Remedies for doshas if found",
      "Joint consultation call"
    ]
  },
  {
    id: "vastu",
    name: "Vastu Report",
    price: 2999,
    tagline: "Harmonise your space",
    features: [
      "Floor-plan analysis (up to 2000 sq ft)",
      "Direction-wise energy mapping",
      "Room-by-room recommendations",
      "No-demolition remedies only",
      "Prosperity corner activation guide",
      "60-min video walkthrough"
    ]
  }
];
