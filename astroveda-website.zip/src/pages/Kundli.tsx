import { useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { TextField, MenuItem, CircularProgress } from "@mui/material";
import { motion, AnimatePresence } from "framer-motion";
import SEO from "../components/SEO";
import Reveal from "../components/Reveal";
import { generateKundli, type KundliResult } from "../lib/astrology";
import { geocodePlace } from "../lib/geocode";
import { downloadKundliPdf } from "../lib/pdf";
import { saveRecord } from "../lib/storage";
import { emailAdmin, emailUser, emailEnabled } from "../lib/email";
import { useToast } from "../context/ToastContext";

interface FormValues {
  name: string;
  gender: string;
  date: string;
  time: string;
  place: string;
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl bg-white/70 p-4">
      <p className="text-xs font-bold uppercase tracking-widest text-gold-600">{label}</p>
      <p className="mt-1 font-semibold text-ink">{value}</p>
    </div>
  );
}

export default function Kundli() {
  const { toast } = useToast();
  const [result, setResult] = useState<KundliResult | null>(null);
  const [generating, setGenerating] = useState(false);
  const [emailing, setEmailing] = useState(false);
  const reportRef = useRef<HTMLDivElement>(null);

  const {
    register,
    handleSubmit,
    formState: { errors }
  } = useForm<FormValues>({ defaultValues: { gender: "Female" } });

  const onSubmit = async (values: FormValues) => {
    setGenerating(true);
    try {
      const geo = geocodePlace(values.place);
      const kundli = generateKundli({
        ...values,
        latitude: geo.lat,
        longitude: geo.lon,
        tzOffsetHours: geo.tz
      });
      setResult(kundli);

      // Save the lead
      await saveRecord("leads", {
        type: "kundli",
        source: "kundli-generator",
        name: values.name,
        gender: values.gender,
        dob: values.date,
        tob: values.time,
        place: values.place,
        moonSign: kundli.moon.rashi,
        nakshatra: kundli.nakshatra.name
      });
      emailAdmin({
        subject: "New Kundli generated",
        message: `Name: ${values.name}\nDOB: ${values.date} ${values.time}\nPlace: ${values.place}\nMoon sign: ${kundli.moon.rashi}\nNakshatra: ${kundli.nakshatra.name}`
      });

      setTimeout(() => reportRef.current?.scrollIntoView({ behavior: "smooth", block: "start" }), 150);
      toast("Your Kundli is ready! Scroll down to view and download.");
    } catch (e) {
      console.error(e);
      toast("We couldn't compute the chart from those details. Please re-check date and time.", "error");
    } finally {
      setGenerating(false);
    }
  };

  const handleEmailReport = async () => {
    if (!result) return;
    const email = window.prompt("Enter the email address to send this report to:");
    if (!email) return;
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      toast("That doesn't look like a valid email address.", "error");
      return;
    }
    setEmailing(true);
    const k = result;
    const sent = await emailUser({
      to_email: email,
      to_name: k.input.name,
      subject: `Your Janma Kundli Report — ${k.input.name}`,
      message:
        `Namaste ${k.input.name},\n\nHere is the summary of your Janma Kundli:\n\n` +
        `Lagna: ${k.lagna.rashi}\nMoon sign: ${k.moon.rashi}\nNakshatra: ${k.nakshatra.name} (Pada ${k.nakshatra.pada})\n` +
        `Tithi: ${k.tithi.name}\nYoga: ${k.yoga}\nGemstone: ${k.gemstone}\n` +
        `Lucky numbers: ${k.luckyNumbers.join(", ")}\nLucky colours: ${k.luckyColors.join(", ")}\n\n` +
        `Current dasha sequence:\n${k.dashas.slice(0, 3).map((d) => `• ${d.lord}: ${d.startYear} – ${d.endYear}`).join("\n")}\n\n` +
        `For the full PDF and a consultant walkthrough, reply to this email or visit our website.\n\n— Team AstroVeda`
    });
    setEmailing(false);
    if (sent) {
      await saveRecord("leads", { type: "kundli-email", source: "kundli-generator", name: k.input.name, email });
      toast(`Report emailed to ${email}.`);
    } else if (!emailEnabled) {
      toast("Email service is not configured yet. Add your EmailJS keys in .env to enable sending.", "warning");
    } else {
      toast("The email could not be sent. Please try again.", "error");
    }
  };

  return (
    <main>
      <SEO
        title="Free Kundli Generator"
        description="Generate your free Janma Kundli online — lagna, moon sign, nakshatra, tithi, Vimshottari dasha and a downloadable PDF report."
      />

      <section className="mx-auto max-w-7xl px-4 pt-14 sm:px-6">
        <Reveal>
          <p className="eyebrow">Free · Instant · Sidereal (Lahiri)</p>
          <h1 className="h-display mt-2 text-4xl sm:text-5xl">Kundli Generator</h1>
          <p className="mt-4 max-w-2xl text-ink/70">
            Enter your birth details and get your lagna, moon sign, nakshatra, panchanga and full
            Vimshottari dasha timeline — with a professional PDF you can download or email.
          </p>
        </Reveal>
      </section>

      <section className="mx-auto max-w-3xl px-4 py-10 sm:px-6">
        <Reveal>
          <form onSubmit={handleSubmit(onSubmit)} noValidate className="glass grid gap-4 p-6 sm:p-8">
            <div className="grid gap-4 sm:grid-cols-2">
              <TextField
                label="Full name"
                fullWidth
                error={!!errors.name}
                helperText={errors.name?.message}
                {...register("name", { required: "Please enter the full name", minLength: { value: 2, message: "Name looks too short" } })}
              />
              <TextField
                label="Gender"
                select
                fullWidth
                defaultValue="Female"
                error={!!errors.gender}
                helperText={errors.gender?.message}
                {...register("gender", { required: "Select a gender" })}
              >
                {["Female", "Male", "Other"].map((g) => (
                  <MenuItem key={g} value={g}>{g}</MenuItem>
                ))}
              </TextField>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <TextField
                label="Date of birth"
                type="date"
                fullWidth
                InputLabelProps={{ shrink: true }}
                error={!!errors.date}
                helperText={errors.date?.message}
                {...register("date", {
                  required: "Date of birth is required",
                  validate: (v) => new Date(v) <= new Date() || "Birth date can't be in the future"
                })}
              />
              <TextField
                label="Time of birth"
                type="time"
                fullWidth
                InputLabelProps={{ shrink: true }}
                error={!!errors.time}
                helperText={errors.time?.message || "As exact as possible — even 15 min changes the lagna"}
                {...register("time", { required: "Time of birth is required" })}
              />
            </div>
            <TextField
              label="Birth place (city)"
              fullWidth
              placeholder="e.g. Jaipur, Mumbai, London"
              error={!!errors.place}
              helperText={errors.place?.message}
              {...register("place", { required: "Birth place is required", minLength: { value: 2, message: "Enter a city name" } })}
            />
            <button type="submit" className="btn-gold mt-2 justify-self-start" disabled={generating}>
              {generating ? <CircularProgress size={18} color="inherit" /> : <span aria-hidden>✦</span>}
              {generating ? "Computing chart…" : "Generate Kundli"}
            </button>
          </form>
        </Reveal>
      </section>

      <AnimatePresence>
        {result && (
          <motion.section
            ref={reportRef}
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="mx-auto max-w-4xl px-4 pb-16 sm:px-6"
          >
            <div className="glass p-6 sm:p-10">
              <div className="flex flex-wrap items-start justify-between gap-4">
                <div>
                  <p className="eyebrow">Janma Kundli</p>
                  <h2 className="h-display mt-1 text-3xl">{result.input.name}</h2>
                  <p className="mt-1 text-sm text-ink/60">
                    {result.input.date} · {result.input.time} · {result.input.place}
                  </p>
                </div>
                <div className="flex flex-wrap gap-2">
                  <button className="btn-royal !py-2 text-sm" onClick={() => downloadKundliPdf(result)}>
                    ⬇ Download PDF
                  </button>
                  <button className="btn-ghost !py-2 text-sm" onClick={handleEmailReport} disabled={emailing}>
                    {emailing ? "Sending…" : "✉ Email report"}
                  </button>
                </div>
              </div>

              <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                <Stat label="Lagna (Ascendant)" value={result.lagna.rashi} />
                <Stat label="Moon sign (Rashi)" value={result.moon.rashi} />
                <Stat label="Sun sign" value={result.sun.rashi} />
                <Stat label="Nakshatra" value={`${result.nakshatra.name} · Pada ${result.nakshatra.pada}`} />
                <Stat label="Tithi" value={result.tithi.name} />
                <Stat label="Yoga / Karana" value={`${result.yoga} / ${result.karana}`} />
              </div>

              <h3 className="h-display mt-10 text-2xl">Personality insights</h3>
              <ul className="mt-3 space-y-2 text-sm text-ink/80">
                {result.traits.map((t) => (
                  <li key={t} className="flex gap-2">
                    <span className="text-gold-500" aria-hidden>✦</span> {t}
                  </li>
                ))}
              </ul>

              <div className="mt-8 grid gap-4 sm:grid-cols-3">
                <Stat label="Lucky numbers" value={result.luckyNumbers.join(", ")} />
                <Stat label="Lucky colours" value={result.luckyColors.join(", ")} />
                <Stat label="Gemstone" value={result.gemstone} />
              </div>

              <h3 className="h-display mt-10 text-2xl">Vimshottari Dasha timeline</h3>
              <div className="mt-4 overflow-x-auto">
                <table className="w-full min-w-[420px] text-left text-sm">
                  <thead>
                    <tr className="bg-royal-700 text-white">
                      <th className="rounded-l-xl px-4 py-2.5">Dasha lord</th>
                      <th className="px-4 py-2.5">Start</th>
                      <th className="px-4 py-2.5">End</th>
                      <th className="rounded-r-xl px-4 py-2.5">Duration</th>
                    </tr>
                  </thead>
                  <tbody>
                    {result.dashas.map((d, i) => (
                      <tr key={d.lord + i} className={i % 2 ? "bg-royal-50/70" : ""}>
                        <td className="px-4 py-2 font-semibold">{d.lord}</td>
                        <td className="px-4 py-2">{d.startYear}</td>
                        <td className="px-4 py-2">{d.endYear}</td>
                        <td className="px-4 py-2">{d.years} yrs</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <p className="mt-8 rounded-2xl bg-royal-50 p-4 text-xs text-ink/60">
                Computed with Lahiri ayanamsa ({result.ayanamsa}°). For a house-by-house reading with
                remedies, book a consultation — your generated chart will be used as the starting point.
              </p>
            </div>
          </motion.section>
        )}
      </AnimatePresence>
    </main>
  );
}
