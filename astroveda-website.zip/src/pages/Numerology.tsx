import ServicePageLayout from "../components/ServicePageLayout";
import { numerologyServices } from "../data/services";

export default function Numerology() {
  return (
    <ServicePageLayout
      seoTitle="Numerology Services"
      seoDescription="Name numerology, name correction, business name numerology, mobile number analysis, vehicle number suggestions and signature analysis."
      eyebrow="Ank Shastra · The power of numbers"
      title="Numerology Services"
      intro="Your name and the numbers around you broadcast a frequency every day. We measure it against your birth numbers and tune what's out of harmony — often with changes as small as a single letter."
      items={numerologyServices}
      source="numerology"
    />
  );
}
