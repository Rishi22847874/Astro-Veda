import { Helmet } from "react-helmet-async";
import { useLocation } from "react-router-dom";
import { site } from "../config/site";

interface SEOProps {
  title: string;
  description: string;
  type?: string;
  schema?: Record<string, any>;
}

export default function SEO({ title, description, type = "website", schema }: SEOProps) {
  const { pathname } = useLocation();
  const url = site.url + pathname;
  const fullTitle = `${title} | ${site.name}`;

  const baseSchema = {
    "@context": "https://schema.org",
    "@type": "ProfessionalService",
    name: site.name,
    description: site.tagline,
    url: site.url,
    telephone: site.phone,
    email: site.email,
    address: { "@type": "PostalAddress", streetAddress: site.address, addressCountry: "IN" },
    priceRange: "₹₹",
    sameAs: Object.values(site.social)
  };

  return (
    <Helmet>
      <title>{fullTitle}</title>
      <meta name="description" content={description} />
      <link rel="canonical" href={url} />
      {/* Open Graph */}
      <meta property="og:title" content={fullTitle} />
      <meta property="og:description" content={description} />
      <meta property="og:type" content={type} />
      <meta property="og:url" content={url} />
      <meta property="og:site_name" content={site.name} />
      <meta property="og:image" content={`${site.url}/og-image.png`} />
      {/* Twitter */}
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:title" content={fullTitle} />
      <meta name="twitter:description" content={description} />
      <meta name="twitter:image" content={`${site.url}/og-image.png`} />
      {/* Schema */}
      <script type="application/ld+json">{JSON.stringify(schema || baseSchema)}</script>
    </Helmet>
  );
}
