import { Link, useParams, Navigate } from "react-router-dom";
import SEO from "../components/SEO";
import Reveal from "../components/Reveal";
import { blogPosts } from "../data/blog";
import { whatsappLink } from "../lib/whatsapp";

export default function BlogPost() {
  const { slug } = useParams();
  const post = blogPosts.find((p) => p.slug === slug);

  if (!post) return <Navigate to="/blog" replace />;

  const related = blogPosts.filter((p) => p.category === post.category && p.slug !== post.slug).slice(0, 3);

  return (
    <main>
      <SEO
        title={post.title}
        description={post.excerpt}
        type="article"
        schema={{
          "@context": "https://schema.org",
          "@type": "BlogPosting",
          headline: post.title,
          description: post.excerpt,
          datePublished: post.date,
          author: { "@type": "Organization", name: "AstroVeda" }
        }}
      />

      <article className="bg-gradient-to-b from-royal-50 to-white pt-28 pb-20">
        <div className="mx-auto max-w-3xl px-4">
          <Reveal>
            <Link to="/blog" className="text-sm text-royal-700 hover:underline underline-offset-4">
              ← All articles
            </Link>
            <div className="mt-6 flex items-center gap-3">
              <span className="rounded-full bg-royal-50 border border-royal-100 px-3 py-1 text-xs font-semibold text-royal-800">
                {post.category}
              </span>
              <span className="text-xs text-ink/50">{post.date} · {post.readMins} min read</span>
            </div>
            <h1 className="mt-4 font-display text-3xl md:text-5xl leading-tight text-ink">
              {post.emoji} {post.title}
            </h1>
          </Reveal>

          <Reveal delay={0.1} className="mt-10 space-y-6">
            {post.content.map((para, i) => (
              <p key={i} className="text-[1.05rem] leading-8 text-ink/80">{para}</p>
            ))}
          </Reveal>

          <Reveal delay={0.15} className="mt-12 rounded-3xl bg-gradient-to-r from-royal-800 to-royal-900 p-8 text-center text-white">
            <h2 className="font-display text-2xl">Want guidance personalised to your chart?</h2>
            <p className="mt-2 text-white/75 text-sm">
              Book a one-on-one session or message us on WhatsApp — first response within minutes.
            </p>
            <div className="mt-5 flex flex-col sm:flex-row gap-3 justify-center">
              <Link to="/book-consultation" className="btn-gold">Book a Consultation</Link>
              <a
                href={whatsappLink(`Hi! I just read "${post.title}" on your blog and have a question.`)}
                target="_blank" rel="noreferrer" className="btn-ghost !text-white !border-white/40"
              >
                Chat on WhatsApp
              </a>
            </div>
          </Reveal>
        </div>
      </article>

      {related.length > 0 && (
        <section className="pb-24">
          <div className="mx-auto max-w-6xl px-4">
            <Reveal>
              <h2 className="font-display text-2xl text-ink">Related reading</h2>
            </Reveal>
            <div className="mt-6 grid gap-6 md:grid-cols-3">
              {related.map((p, i) => (
                <Reveal key={p.slug} delay={i * 0.07}>
                  <Link
                    to={`/blog/${p.slug}`}
                    className="group block h-full glass rounded-3xl border border-royal-100 p-6 hover:shadow-xl transition-shadow"
                  >
                    <span className="text-3xl">{p.emoji}</span>
                    <h3 className="mt-3 font-display text-lg text-ink group-hover:text-royal-700 transition-colors">
                      {p.title}
                    </h3>
                    <p className="mt-2 text-sm text-ink/60 line-clamp-2">{p.excerpt}</p>
                  </Link>
                </Reveal>
              ))}
            </div>
          </div>
        </section>
      )}
    </main>
  );
}
