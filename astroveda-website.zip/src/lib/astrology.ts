/**
 * Vedic astrology calculations (sidereal, Lahiri ayanamsa).
 *
 * Sun/Moon longitudes use truncated VSOP/ELP series — accurate to well under
 * 0.5° for the Moon and 0.01° for the Sun, which is sufficient for rashi,
 * nakshatra, lagna and Vimshottari dasha determination.
 */

export interface BirthInput {
  name: string;
  gender: string;
  date: string; // yyyy-mm-dd
  time: string; // HH:mm (local)
  place: string;
  latitude?: number;
  longitude?: number;
  tzOffsetHours?: number; // default +5.5 (IST)
}

export interface KundliResult {
  input: BirthInput;
  julianDay: number;
  ayanamsa: number;
  sun: BodyPosition;
  moon: BodyPosition;
  lagna: BodyPosition;
  nakshatra: { name: string; pada: number; lord: string };
  tithi: { name: string; index: number };
  yoga: string;
  karana: string;
  dashas: DashaPeriod[];
  traits: string[];
  luckyNumbers: number[];
  luckyColors: string[];
  gemstone: string;
}

export interface BodyPosition {
  longitude: number; // sidereal
  rashi: string;
  rashiIndex: number;
  degreeInSign: number;
}

export interface DashaPeriod {
  lord: string;
  startYear: number;
  endYear: number;
  years: number;
}

export const RASHIS = [
  "Mesha (Aries)", "Vrishabha (Taurus)", "Mithuna (Gemini)", "Karka (Cancer)",
  "Simha (Leo)", "Kanya (Virgo)", "Tula (Libra)", "Vrishchika (Scorpio)",
  "Dhanu (Sagittarius)", "Makara (Capricorn)", "Kumbha (Aquarius)", "Meena (Pisces)"
];

export const NAKSHATRAS = [
  "Ashwini", "Bharani", "Krittika", "Rohini", "Mrigashira", "Ardra", "Punarvasu",
  "Pushya", "Ashlesha", "Magha", "Purva Phalguni", "Uttara Phalguni", "Hasta",
  "Chitra", "Swati", "Vishakha", "Anuradha", "Jyeshtha", "Mula", "Purva Ashadha",
  "Uttara Ashadha", "Shravana", "Dhanishta", "Shatabhisha", "Purva Bhadrapada",
  "Uttara Bhadrapada", "Revati"
];

const NAKSHATRA_LORDS = [
  "Ketu", "Venus", "Sun", "Moon", "Mars", "Rahu", "Jupiter", "Saturn", "Mercury",
  "Ketu", "Venus", "Sun", "Moon", "Mars", "Rahu", "Jupiter", "Saturn", "Mercury",
  "Ketu", "Venus", "Sun", "Moon", "Mars", "Rahu", "Jupiter", "Saturn", "Mercury"
];

const DASHA_YEARS: Record<string, number> = {
  Ketu: 7, Venus: 20, Sun: 6, Moon: 10, Mars: 7, Rahu: 18, Jupiter: 16, Saturn: 19, Mercury: 17
};

const DASHA_ORDER = ["Ketu", "Venus", "Sun", "Moon", "Mars", "Rahu", "Jupiter", "Saturn", "Mercury"];

const TITHIS = [
  "Pratipada", "Dwitiya", "Tritiya", "Chaturthi", "Panchami", "Shashthi", "Saptami",
  "Ashtami", "Navami", "Dashami", "Ekadashi", "Dwadashi", "Trayodashi", "Chaturdashi", "Purnima/Amavasya"
];

const YOGAS = [
  "Vishkambha", "Priti", "Ayushman", "Saubhagya", "Shobhana", "Atiganda", "Sukarma",
  "Dhriti", "Shula", "Ganda", "Vriddhi", "Dhruva", "Vyaghata", "Harshana", "Vajra",
  "Siddhi", "Vyatipata", "Variyan", "Parigha", "Shiva", "Siddha", "Sadhya", "Shubha",
  "Shukla", "Brahma", "Indra", "Vaidhriti"
];

const KARANAS = ["Bava", "Balava", "Kaulava", "Taitila", "Garaja", "Vanija", "Vishti"];

const SIGN_TRAITS: Record<number, string[]> = {
  0: ["Courageous and pioneering", "Natural leadership instincts", "Acts quickly on decisions"],
  1: ["Steady, patient and reliable", "Strong appreciation for comfort and beauty", "Loyal in relationships"],
  2: ["Quick-witted communicator", "Adaptable and curious", "Thrives on variety"],
  3: ["Deeply intuitive and nurturing", "Strong emotional memory", "Protective of loved ones"],
  4: ["Confident and generous", "Natural performer and motivator", "Strong sense of dignity"],
  5: ["Analytical and detail-oriented", "Service-minded perfectionist", "Practical problem solver"],
  6: ["Diplomatic and fair-minded", "Drawn to harmony and partnership", "Refined aesthetic sense"],
  7: ["Intense and transformative", "Powerful intuition", "Unwavering determination"],
  8: ["Optimistic truth-seeker", "Loves freedom and exploration", "Philosophical outlook"],
  9: ["Disciplined and ambitious", "Builds lasting structures", "Patient long-term planner"],
  10: ["Original, humanitarian thinker", "Values independence", "Visionary about the future"],
  11: ["Compassionate dreamer", "Artistic and spiritual leanings", "Deep empathy for others"]
};

const SIGN_GEMS = [
  "Red Coral (Moonga)", "Diamond (Heera)", "Emerald (Panna)", "Pearl (Moti)",
  "Ruby (Manik)", "Emerald (Panna)", "Diamond (Heera)", "Red Coral (Moonga)",
  "Yellow Sapphire (Pukhraj)", "Blue Sapphire (Neelam)", "Blue Sapphire (Neelam)", "Yellow Sapphire (Pukhraj)"
];

const SIGN_COLORS = [
  ["Red", "Saffron"], ["White", "Green"], ["Green", "Yellow"], ["White", "Silver"],
  ["Gold", "Orange"], ["Green", "White"], ["White", "Blue"], ["Red", "Maroon"],
  ["Yellow", "Gold"], ["Black", "Indigo"], ["Blue", "Black"], ["Yellow", "Sea Green"]
];

const deg2rad = (d: number) => (d * Math.PI) / 180;
const norm360 = (d: number) => ((d % 360) + 360) % 360;

/** Julian Day from a UT date. */
export function julianDay(y: number, m: number, d: number, utHours: number): number {
  if (m <= 2) { y -= 1; m += 12; }
  const A = Math.floor(y / 100);
  const B = 2 - A + Math.floor(A / 4);
  return Math.floor(365.25 * (y + 4716)) + Math.floor(30.6001 * (m + 1)) + d + B - 1524.5 + utHours / 24;
}

/** Lahiri ayanamsa (approx, deg). */
function lahiriAyanamsa(jd: number): number {
  const t = (jd - 2451545.0) / 36525;
  return 23.85675 + 1.396042 * t + 0.000308 * t * t; // ~23.86° at J2000, drift ~50.3"/yr
}

/** Tropical geometric Sun longitude (deg). */
function sunLongitude(jd: number): number {
  const T = (jd - 2451545.0) / 36525;
  const L0 = norm360(280.46646 + 36000.76983 * T + 0.0003032 * T * T);
  const M = deg2rad(norm360(357.52911 + 35999.05029 * T - 0.0001537 * T * T));
  const C =
    (1.914602 - 0.004817 * T - 0.000014 * T * T) * Math.sin(M) +
    (0.019993 - 0.000101 * T) * Math.sin(2 * M) +
    0.000289 * Math.sin(3 * M);
  return norm360(L0 + C);
}

/** Tropical Moon longitude (deg) — principal ELP terms. */
function moonLongitude(jd: number): number {
  const T = (jd - 2451545.0) / 36525;
  const Lp = norm360(218.3164477 + 481267.88123421 * T - 0.0015786 * T * T);
  const D = deg2rad(norm360(297.8501921 + 445267.1114034 * T - 0.0018819 * T * T));
  const M = deg2rad(norm360(357.5291092 + 35999.0502909 * T - 0.0001536 * T * T));
  const Mp = deg2rad(norm360(134.9633964 + 477198.8675055 * T + 0.0087414 * T * T));
  const F = deg2rad(norm360(93.272095 + 483202.0175233 * T - 0.0036539 * T * T));
  const dL =
    6.288774 * Math.sin(Mp) +
    1.274027 * Math.sin(2 * D - Mp) +
    0.658314 * Math.sin(2 * D) +
    0.213618 * Math.sin(2 * Mp) -
    0.185116 * Math.sin(M) -
    0.114332 * Math.sin(2 * F) +
    0.058793 * Math.sin(2 * D - 2 * Mp) +
    0.057066 * Math.sin(2 * D - M - Mp) +
    0.053322 * Math.sin(2 * D + Mp) +
    0.045758 * Math.sin(2 * D - M);
  return norm360(Lp + dL);
}

/** Local sidereal time (deg). */
function localSiderealTime(jd: number, longitudeEast: number): number {
  const T = (jd - 2451545.0) / 36525;
  const gmst = 280.46061837 + 360.98564736629 * (jd - 2451545.0) + 0.000387933 * T * T;
  return norm360(gmst + longitudeEast);
}

/** Tropical ascendant longitude (deg). */
function ascendant(jd: number, latitude: number, longitudeEast: number): number {
  const lst = deg2rad(localSiderealTime(jd, longitudeEast));
  const eps = deg2rad(23.4392911);
  const lat = deg2rad(latitude);
  const asc = Math.atan2(Math.cos(lst), -(Math.sin(lst) * Math.cos(eps) + Math.tan(lat) * Math.sin(eps)));
  return norm360((asc * 180) / Math.PI);
}

function toPosition(siderealLon: number): BodyPosition {
  const idx = Math.floor(siderealLon / 30);
  return {
    longitude: siderealLon,
    rashi: RASHIS[idx],
    rashiIndex: idx,
    degreeInSign: siderealLon - idx * 30
  };
}

function vimshottari(moonSidereal: number, birthYear: number): DashaPeriod[] {
  const nakIndex = Math.floor(moonSidereal / (360 / 27));
  const lord = NAKSHATRA_LORDS[nakIndex];
  const fractionTraversed = (moonSidereal % (360 / 27)) / (360 / 27);
  const startIdx = DASHA_ORDER.indexOf(lord);
  const balance = DASHA_YEARS[lord] * (1 - fractionTraversed);

  const periods: DashaPeriod[] = [];
  let cursor = birthYear;
  for (let i = 0; i < 9; i++) {
    const l = DASHA_ORDER[(startIdx + i) % 9];
    const span = i === 0 ? balance : DASHA_YEARS[l];
    periods.push({
      lord: l,
      startYear: Math.round(cursor * 10) / 10,
      endYear: Math.round((cursor + span) * 10) / 10,
      years: Math.round(span * 10) / 10
    });
    cursor += span;
  }
  return periods;
}

/** Generate a full Kundli from birth details. */
export function generateKundli(input: BirthInput): KundliResult {
  const [y, m, d] = input.date.split("-").map(Number);
  const [hh, mm] = input.time.split(":").map(Number);
  const tz = input.tzOffsetHours ?? 5.5;
  const lat = input.latitude ?? 28.6139; // Delhi default when geocode unknown
  const lon = input.longitude ?? 77.209;

  const utHours = hh + mm / 60 - tz;
  const jd = julianDay(y, m, d, utHours);
  const aya = lahiriAyanamsa(jd);

  const sunTrop = sunLongitude(jd);
  const moonTrop = moonLongitude(jd);
  const ascTrop = ascendant(jd, lat, lon);

  const sunSid = norm360(sunTrop - aya);
  const moonSid = norm360(moonTrop - aya);
  const lagnaSid = norm360(ascTrop - aya);

  const nakIndex = Math.floor(moonSid / (360 / 27));
  const pada = Math.floor((moonSid % (360 / 27)) / (360 / 108)) + 1;

  const elong = norm360(moonTrop - sunTrop);
  const tithiIndex = Math.floor(elong / 12); // 0..29
  const yogaIndex = Math.floor(norm360(sunTrop + moonTrop) / (360 / 27));
  const karanaIndex = Math.floor(elong / 6) % 7;

  const moonPos = toPosition(moonSid);
  const fractionalYear = y + ((m - 1) * 30 + d) / 365;

  return {
    input,
    julianDay: jd,
    ayanamsa: Math.round(aya * 100) / 100,
    sun: toPosition(sunSid),
    moon: moonPos,
    lagna: toPosition(lagnaSid),
    nakshatra: { name: NAKSHATRAS[nakIndex], pada, lord: NAKSHATRA_LORDS[nakIndex] },
    tithi: { name: TITHIS[tithiIndex % 15], index: tithiIndex + 1 },
    yoga: YOGAS[yogaIndex],
    karana: KARANAS[karanaIndex],
    dashas: vimshottari(moonSid, fractionalYear),
    traits: SIGN_TRAITS[moonPos.rashiIndex],
    luckyNumbers: [((moonPos.rashiIndex + 1) % 9) + 1, ((nakIndex + 3) % 9) + 1, ((d + m) % 9) + 1],
    luckyColors: SIGN_COLORS[moonPos.rashiIndex],
    gemstone: SIGN_GEMS[moonPos.rashiIndex]
  };
}
