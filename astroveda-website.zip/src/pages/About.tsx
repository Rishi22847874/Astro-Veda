import { Link } from "react-router-dom";
import SEO from "../components/SEO";
import Reveal from "../components/Reveal";

const values = [
  { t: "Honest readings", d: "If the chart says wait, we say wait. No fear-selling, no manufactured doshas." },
  { t: "Method over mystery", d: "Every prediction is traceable to a placement, a dasha or a transit you can verify." },
  { t: "Remedies you can do", d: "Practical observances and corrections — not expensive rituals as a first resort." },
  { t: "Privacy first", d: "Birth details are intimate data. They are never shared or sold, ever." }
];

const team = [
  { name: "Pt. Raghav Sharma", role: "Founder · Vedic Astrologer (21 yrs)", emoji: "🧘" },
  { name: "Dr. Meera Iyer", role: "Numerologist & Name Consultant", emoji: "🔢" },
  { name: "Ar. Vikram Joshi", role: "Vastu Architect (B.Arch)", emoji: "📐" }
];

export default function About() {
  return (
    <main>
      <SEO
        title="About Us"
        description="AstroVeda blends 21 years of Vedic practice with precise sidereal computation. Meet the team and the principles behind our readings."
      />
      <section className="mx-auto max-w-7xl px-4 pt-14 sm:px-6">
        <Reveal>
          <p className="eyebrow">About AstroVeda</p>
          <h1 className="h-display mt-2 max-w-3xl text-4xl sm:text-5xl">
            Two decades of practice. One promise: clarity without fear.
          </h1>
          <p className="mt-5 max-w-2xl text-lg text-ink/70">
            AstroVeda began in 2005 as a single consulting desk in Hauz Khas, Delhi. Today we serve
            seekers in 14 countries — but every chart is still read the same way: carefully, honestly,
            and with your wellbeing above our invoice.
          </p>
        </Reveal>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-14 sm:px-6">
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {values.map((v, i) => (
            <Reveal key={v.t} delay={i * 0.06}>
              <div className="glass h-full p-6">
                <span className="text-2xl text-gold-500" aria-hidden>✦</span>
                <h2 className="h-display mt-2 text-xl">{v.t}</h2>
                <p className="mt-2 text-sm text-ink/70">{v.d}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      <section className="bg-royal-50/70 py-14">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <Reveal>
            <p className="eyebrow">The consultants</p>
            <h2 className="h-display mt-2 text-3xl sm:text-4xl">Who reads your chart</h2>
          </Reveal>
          <div className="mt-8 grid gap-6 md:grid-cols-3">
            {team.map((t, i) => (
              <Reveal key={t.name} delay={i * 0.07}>
                <div className="glass flex h-full items-center gap-4 p-6">
                  <span className="grid h-16 w-16 shrink-0 place-items-center rounded-full bg-royal-700 text-3xl">
                    {t.emoji}
                  </span>
                  <div>
                    <h3 className="h-display text-lg">{t.name}</h3>
                    <p className="text-sm text-ink/60">{t.role}</p>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-4xl px-4 py-14 text-center sm:px-6">
        <Reveal>
          <h2 className="h-display text-3xl">Ready when you are</h2>
          <div className="mt-6 flex flex-wrap justify-center gap-3">
            <Link to="/book-consultation" className="btn-gold">Book a consultation</Link>
            <Link to="/services" className="btn-ghost">Browse services</Link>
          </div>
        </Reveal>
      </section>
    </main>
  );
}
