import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import SEO from "../components/SEO";

export default function NotFound() {
  return (
    <main className="min-h-[80vh] flex items-center justify-center bg-gradient-to-b from-royal-50 to-white pt-24 pb-16">
      <SEO title="Page Not Found" description="The page you were looking for has drifted into another constellation." />
      <div className="text-center px-4">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 40, repeat: Infinity, ease: "linear" }}
          className="mx-auto h-28 w-28 rounded-full border-2 border-dashed border-royal-300 flex items-center justify-center text-5xl"
        >
          🪐
        </motion.div>
        <h1 className="mt-8 font-display text-6xl text-royal-800">404</h1>
        <p className="mt-3 font-display text-2xl text-ink">This page has drifted into another constellation</p>
        <p className="mt-2 text-ink/60 text-sm max-w-md mx-auto">
          The stars couldn't locate what you were looking for. Let's guide you back to familiar skies.
        </p>
        <div className="mt-8 flex flex-col sm:flex-row gap-3 justify-center">
          <Link to="/" className="btn-royal">Back to Home</Link>
          <Link to="/kundli" className="btn-ghost">Generate Free Kundli</Link>
        </div>
      </div>
    </main>
  );
}
