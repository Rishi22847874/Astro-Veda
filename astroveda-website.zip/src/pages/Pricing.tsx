import { useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  Dialog, DialogTitle, DialogContent, TextField, Button, Stack, CircularProgress
} from "@mui/material";
import { useForm } from "react-hook-form";
import SEO from "../components/SEO";
import Reveal from "../components/Reveal";
import { packages, type PricingPackage } from "../data/pricing";
import { openCheckout } from "../lib/razorpay";
import { saveRecord } from "../lib/storage";
import { emailUser, emailAdmin } from "../lib/email";
import { whatsappLink } from "../lib/whatsapp";
import { useToast } from "../context/ToastContext";

interface BuyerForm { name: string; email: string; phone: string; }

export default function Pricing() {
  const [selected, setSelected] = useState<PricingPackage | null>(null);
  const [paying, setPaying] = useState(false);
  const { toast } = useToast();
  const navigate = useNavigate();
  const { register, handleSubmit, reset, formState: { errors } } = useForm<BuyerForm>();

  const startPayment = async (data: BuyerForm) => {
    if (!selected) return;
    setPaying(true);
    const result = await openCheckout({
      amount: selected.price,
      description: `${selected.name} — AstroVeda Consultation`,
      name: data.name,
      email: data.email,
      phone: data.phone
    });
    setPaying(false);

    if (!result.success) {
      toast(result.error || "Payment was not completed.", "error");
      return;
    }

    const invoiceNo = "AV-" + Date.now().toString().slice(-8);
    const payment = {
      invoiceNo,
      packageId: selected.id,
      packageName: selected.name,
      amount: selected.price,
      paymentId: result.paymentId,
      demo: result.demo,
      name: data.name,
      email: data.email,
      phone: data.phone
    };
    await saveRecord("payments", payment);

    emailUser({
      to_email: data.email,
      to_name: data.name,
      subject: `Payment received — ${selected.name} (${invoiceNo})`,
      message: `Thank you ${data.name}! We have received ₹${selected.price} for the ${selected.name}. Payment ID: ${result.paymentId}. Our astrologer will reach out within 24 hours to schedule your session.`
    });
    emailAdmin({
      subject: `New payment ₹${selected.price} — ${selected.name}`,
      message: `${data.name} (${data.phone}, ${data.email}) purchased ${selected.name}. Payment ID: ${result.paymentId}. Invoice: ${invoiceNo}.`
    });

    setSelected(null);
    reset();
    navigate("/payment-success", {
      state: {
        invoice: {
          invoiceNo,
          customerName: data.name,
          customerEmail: data.email,
          customerPhone: data.phone,
          packageName: selected.name,
          amount: selected.price,
          paymentId: result.paymentId,
          date: new Date().toLocaleDateString("en-IN", { day: "2-digit", month: "long", year: "numeric" })
        },
        demo: result.demo
      }
    });
  };

  return (
    <main>
      <SEO
        title="Pricing & Consultation Packages"
        description="Transparent pricing for astrology, numerology and Vastu consultations. Secure online payment, instant invoice, and a session within 24 hours."
      />

      <section className="bg-gradient-to-b from-royal-50 to-white pt-28 pb-16">
        <div className="mx-auto max-w-6xl px-4 text-center">
          <Reveal>
            <p className="eyebrow">Pricing</p>
            <h1 className="font-display text-4xl md:text-5xl text-ink mt-3">
              Simple plans, <span className="text-royal-700">profound guidance</span>
            </h1>
            <p className="mt-4 text-ink/70 max-w-2xl mx-auto">
              Every package includes a live one-on-one session, a written summary, and remedy
              recommendations. Pay securely online — your invoice is generated instantly.
            </p>
          </Reveal>
        </div>
      </section>

      <section className="pb-24 -mt-4">
        <div className="mx-auto max-w-6xl px-4 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {packages.map((p, i) => (
            <Reveal key={p.id} delay={i * 0.07}>
              <div
                className={`relative h-full rounded-3xl p-8 flex flex-col border transition-shadow hover:shadow-xl ${
                  p.popular
                    ? "bg-gradient-to-b from-royal-800 to-royal-900 text-white border-royal-700 shadow-lg"
                    : "glass border-royal-100"
                }`}
              >
                {p.popular && (
                  <span className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-gold-500 px-4 py-1 text-xs font-bold tracking-wide text-ink">
                    MOST POPULAR
                  </span>
                )}
                <h3 className={`font-display text-2xl ${p.popular ? "text-white" : "text-ink"}`}>{p.name}</h3>
                <p className={`mt-1 text-sm ${p.popular ? "text-white/70" : "text-ink/60"}`}>{p.tagline}</p>
                <div className="mt-5 flex items-baseline gap-1">
                  <span className={`font-display text-4xl ${p.popular ? "text-gold-400" : "text-royal-800"}`}>
                    ₹{p.price.toLocaleString("en-IN")}
                  </span>
                  <span className={`text-sm ${p.popular ? "text-white/60" : "text-ink/50"}`}>/ session</span>
                </div>
                <ul className="mt-6 space-y-3 flex-1">
                  {p.features.map((f) => (
                    <li key={f} className={`flex gap-2 text-sm ${p.popular ? "text-white/85" : "text-ink/75"}`}>
                      <span className={p.popular ? "text-gold-400" : "text-gold-600"}>✦</span> {f}
                    </li>
                  ))}
                </ul>
                <button
                  onClick={() => setSelected(p)}
                  className={`mt-8 w-full rounded-full py-3 font-semibold transition-transform active:scale-95 ${
                    p.popular ? "bg-gold-500 text-ink hover:bg-gold-400" : "btn-royal"
                  }`}
                >
                  Buy Now
                </button>
                <a
                  href={whatsappLink(`Hi! I have a question about the ${p.name} (₹${p.price}).`)}
                  target="_blank"
                  rel="noreferrer"
                  className={`mt-3 text-center text-sm underline-offset-4 hover:underline ${
                    p.popular ? "text-white/70" : "text-royal-700"
                  }`}
                >
                  Ask on WhatsApp first
                </a>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      <Dialog open={Boolean(selected)} onClose={() => !paying && setSelected(null)} fullWidth maxWidth="xs">
        <DialogTitle className="font-display">
          {selected ? `${selected.name} — ₹${selected.price.toLocaleString("en-IN")}` : ""}
        </DialogTitle>
        <DialogContent>
          <form onSubmit={handleSubmit(startPayment)}>
            <Stack spacing={2} mt={1}>
              <TextField
                label="Full name" fullWidth size="small"
                error={!!errors.name} helperText={errors.name?.message}
                {...register("name", { required: "Name is required", minLength: { value: 2, message: "Too short" } })}
              />
              <TextField
                label="Email" fullWidth size="small"
                error={!!errors.email} helperText={errors.email?.message}
                {...register("email", {
                  required: "Email is required",
                  pattern: { value: /^[^@\s]+@[^@\s]+\.[^@\s]+$/, message: "Enter a valid email" }
                })}
              />
              <TextField
                label="Phone (10 digits)" fullWidth size="small"
                error={!!errors.phone} helperText={errors.phone?.message}
                {...register("phone", {
                  required: "Phone is required",
                  pattern: { value: /^[6-9]\d{9}$/, message: "Enter a valid Indian mobile number" }
                })}
              />
              <Button
                type="submit" variant="contained" size="large" disabled={paying}
                sx={{ borderRadius: 99, py: 1.4, bgcolor: "#4527A0", "&:hover": { bgcolor: "#311B92" } }}
              >
                {paying ? <CircularProgress size={22} sx={{ color: "white" }} /> : "Proceed to Pay"}
              </Button>
              <p className="text-xs text-ink/50 text-center">
                Secured by Razorpay · UPI, cards, netbanking & wallets accepted
              </p>
            </Stack>
          </form>
        </DialogContent>
      </Dialog>
    </main>
  );
}
