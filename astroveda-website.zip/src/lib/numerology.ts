/** Chaldean + Pythagorean numerology helpers. */

const PYTHAGOREAN: Record<string, number> = {
  a: 1, j: 1, s: 1, b: 2, k: 2, t: 2, c: 3, l: 3, u: 3, d: 4, m: 4, v: 4,
  e: 5, n: 5, w: 5, f: 6, o: 6, x: 6, g: 7, p: 7, y: 7, h: 8, q: 8, z: 8, i: 9, r: 9
};

export function reduceNumber(n: number, keepMaster = true): number {
  while (n > 9) {
    if (keepMaster && (n === 11 || n === 22 || n === 33)) return n;
    n = String(n).split("").reduce((s, c) => s + Number(c), 0);
  }
  return n;
}

export function nameNumber(name: string): number {
  const total = name.toLowerCase().replace(/[^a-z]/g, "").split("")
    .reduce((s, ch) => s + (PYTHAGOREAN[ch] || 0), 0);
  return reduceNumber(total);
}

export function lifePathNumber(dateISO: string): number {
  const digits = dateISO.replace(/[^0-9]/g, "");
  return reduceNumber(digits.split("").reduce((s, c) => s + Number(c), 0));
}

export function mobileNumber(num: string): number {
  return reduceNumber(num.replace(/[^0-9]/g, "").split("").reduce((s, c) => s + Number(c), 0), false);
}

export const NUMBER_MEANINGS: Record<number, string> = {
  1: "Leadership, independence and pioneering drive. Ruled by the Sun.",
  2: "Diplomacy, partnership and sensitivity. Ruled by the Moon.",
  3: "Creativity, expression and optimism. Ruled by Jupiter.",
  4: "Discipline, structure and hard work. Ruled by Rahu.",
  5: "Freedom, communication and adaptability. Ruled by Mercury.",
  6: "Harmony, luxury and responsibility. Ruled by Venus.",
  7: "Spirituality, analysis and inner wisdom. Ruled by Ketu.",
  8: "Ambition, authority and karma. Ruled by Saturn.",
  9: "Compassion, courage and completion. Ruled by Mars.",
  11: "Master intuitive — heightened insight and inspiration.",
  22: "Master builder — capacity to turn dreams into reality.",
  33: "Master teacher — selfless service and healing."
};
