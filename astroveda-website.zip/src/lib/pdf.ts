import { jsPDF } from "jspdf";
import type { KundliResult } from "./astrology";
import { site } from "../config/site";

const ROYAL: [number, number, number] = [69, 39, 160];
const GOLD: [number, number, number] = [201, 162, 39];
const INK: [number, number, number] = [28, 21, 48];

function header(doc: jsPDF, title: string) {
  doc.setFillColor(...ROYAL);
  doc.rect(0, 0, 210, 30, "F");
  doc.setFillColor(...GOLD);
  doc.rect(0, 30, 210, 1.5, "F");
  doc.setTextColor(255, 255, 255);
  doc.setFont("times", "bold");
  doc.setFontSize(20);
  doc.text(site.name, 14, 14);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(10);
  doc.text("Astrology  •  Numerology  •  Vastu", 14, 21);
  doc.setFontSize(13);
  doc.text(title, 196, 18, { align: "right" });
}

function footer(doc: jsPDF) {
  const pages = doc.getNumberOfPages();
  for (let i = 1; i <= pages; i++) {
    doc.setPage(i);
    doc.setDrawColor(...GOLD);
    doc.line(14, 285, 196, 285);
    doc.setTextColor(120, 120, 130);
    doc.setFontSize(8);
    doc.text(`${site.name} • ${site.email} • ${site.phone} • ${site.url}`, 105, 291, { align: "center" });
    doc.text(`Page ${i} of ${pages}`, 196, 291, { align: "right" });
  }
}

function sectionTitle(doc: jsPDF, text: string, y: number): number {
  doc.setTextColor(...ROYAL);
  doc.setFont("times", "bold");
  doc.setFontSize(14);
  doc.text(text, 14, y);
  doc.setDrawColor(...GOLD);
  doc.setLineWidth(0.6);
  doc.line(14, y + 2, 60, y + 2);
  return y + 10;
}

function kv(doc: jsPDF, label: string, value: string, y: number): number {
  doc.setFont("helvetica", "bold");
  doc.setFontSize(10);
  doc.setTextColor(...INK);
  doc.text(label, 14, y);
  doc.setFont("helvetica", "normal");
  doc.text(value, 70, y);
  return y + 7;
}

/** Build the Kundli report PDF and return it (caller decides save vs dataURI). */
export function buildKundliPdf(k: KundliResult): jsPDF {
  const doc = new jsPDF();
  header(doc, "Janma Kundli Report");

  let y = 44;
  y = sectionTitle(doc, "Birth Details", y);
  y = kv(doc, "Name", k.input.name, y);
  y = kv(doc, "Gender", k.input.gender, y);
  y = kv(doc, "Date of Birth", k.input.date, y);
  y = kv(doc, "Time of Birth", k.input.time, y);
  y = kv(doc, "Place of Birth", k.input.place, y);
  y = kv(doc, "Ayanamsa (Lahiri)", `${k.ayanamsa}°`, y);

  y += 4;
  y = sectionTitle(doc, "Planetary Positions (Sidereal)", y);
  y = kv(doc, "Lagna (Ascendant)", `${k.lagna.rashi} — ${k.lagna.degreeInSign.toFixed(2)}°`, y);
  y = kv(doc, "Moon Sign (Rashi)", `${k.moon.rashi} — ${k.moon.degreeInSign.toFixed(2)}°`, y);
  y = kv(doc, "Sun Sign", `${k.sun.rashi} — ${k.sun.degreeInSign.toFixed(2)}°`, y);
  y = kv(doc, "Nakshatra", `${k.nakshatra.name}, Pada ${k.nakshatra.pada} (Lord: ${k.nakshatra.lord})`, y);
  y = kv(doc, "Tithi", `${k.tithi.name} (#${k.tithi.index})`, y);
  y = kv(doc, "Yoga / Karana", `${k.yoga} / ${k.karana}`, y);

  y += 4;
  y = sectionTitle(doc, "Personality Insights", y);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(10);
  doc.setTextColor(...INK);
  k.traits.forEach((t) => {
    doc.setFillColor(...GOLD);
    doc.circle(16, y - 1.4, 0.9, "F");
    doc.text(t, 21, y);
    y += 6.5;
  });

  y += 4;
  y = sectionTitle(doc, "Lucky Factors", y);
  y = kv(doc, "Lucky Numbers", k.luckyNumbers.join(", "), y);
  y = kv(doc, "Lucky Colours", k.luckyColors.join(", "), y);
  y = kv(doc, "Recommended Gemstone", k.gemstone, y);

  doc.addPage();
  header(doc, "Vimshottari Dasha");
  let y2 = 44;
  y2 = sectionTitle(doc, "Major Dasha Periods", y2);
  doc.setFillColor(...ROYAL);
  doc.rect(14, y2 - 5, 182, 8, "F");
  doc.setTextColor(255, 255, 255);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(10);
  doc.text("Dasha Lord", 18, y2);
  doc.text("Start (Year)", 90, y2);
  doc.text("End (Year)", 130, y2);
  doc.text("Duration", 170, y2);
  y2 += 9;
  doc.setFont("helvetica", "normal");
  doc.setTextColor(...INK);
  k.dashas.forEach((d, i) => {
    if (i % 2 === 0) {
      doc.setFillColor(246, 243, 251);
      doc.rect(14, y2 - 5, 182, 8, "F");
    }
    doc.text(d.lord, 18, y2);
    doc.text(String(d.startYear), 90, y2);
    doc.text(String(d.endYear), 130, y2);
    doc.text(`${d.years} yrs`, 170, y2);
    y2 += 8;
  });

  y2 += 8;
  doc.setFontSize(8.5);
  doc.setTextColor(120, 120, 130);
  doc.text(
    "This report is generated using sidereal (Lahiri) calculations. For remedial guidance and a detailed",
    14, y2
  );
  doc.text("house-by-house analysis, book a consultation with our astrologers.", 14, y2 + 4.5);

  footer(doc);
  return doc;
}

export function downloadKundliPdf(k: KundliResult) {
  buildKundliPdf(k).save(`Kundli_${k.input.name.replace(/\s+/g, "_")}.pdf`);
}

export interface InvoiceData {
  invoiceNo: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  packageName: string;
  amount: number;
  paymentId: string;
  date: string;
}

export function buildInvoicePdf(inv: InvoiceData): jsPDF {
  const doc = new jsPDF();
  header(doc, "Tax Invoice");
  let y = 44;
  y = sectionTitle(doc, "Invoice Details", y);
  y = kv(doc, "Invoice No.", inv.invoiceNo, y);
  y = kv(doc, "Date", inv.date, y);
  y = kv(doc, "Payment ID", inv.paymentId, y);

  y += 4;
  y = sectionTitle(doc, "Billed To", y);
  y = kv(doc, "Name", inv.customerName, y);
  y = kv(doc, "Email", inv.customerEmail, y);
  y = kv(doc, "Phone", inv.customerPhone, y);

  y += 6;
  doc.setFillColor(...ROYAL);
  doc.rect(14, y - 5, 182, 9, "F");
  doc.setTextColor(255, 255, 255);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(10);
  doc.text("Description", 18, y + 1);
  doc.text("Amount (INR)", 192, y + 1, { align: "right" });
  y += 11;
  doc.setTextColor(...INK);
  doc.setFont("helvetica", "normal");
  doc.text(inv.packageName, 18, y);
  doc.text(`₹ ${inv.amount.toLocaleString("en-IN")}`, 192, y, { align: "right" });
  y += 10;
  doc.setDrawColor(...GOLD);
  doc.line(14, y, 196, y);
  y += 8;
  doc.setFont("helvetica", "bold");
  doc.text("Total Paid", 18, y);
  doc.text(`₹ ${inv.amount.toLocaleString("en-IN")}`, 192, y, { align: "right" });

  y += 16;
  doc.setFontSize(8.5);
  doc.setFont("helvetica", "normal");
  doc.setTextColor(120, 120, 130);
  doc.text("Thank you for your purchase. Your report will be prepared and emailed within 24–48 hours.", 14, y);

  footer(doc);
  return doc;
}

export function downloadInvoicePdf(inv: InvoiceData) {
  buildInvoicePdf(inv).save(`Invoice_${inv.invoiceNo}.pdf`);
}
