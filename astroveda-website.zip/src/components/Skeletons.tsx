export function CardSkeleton() {
  return (
    <div className="glass p-6">
      <div className="skeleton h-8 w-8" />
      <div className="skeleton mt-4 h-5 w-3/4" />
      <div className="skeleton mt-3 h-3 w-full" />
      <div className="skeleton mt-2 h-3 w-5/6" />
      <div className="skeleton mt-5 h-9 w-28 rounded-full" />
    </div>
  );
}

export function GridSkeleton({ count = 6 }: { count?: number }) {
  return (
    <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
      {Array.from({ length: count }).map((_, i) => (
        <CardSkeleton key={i} />
      ))}
    </div>
  );
}
