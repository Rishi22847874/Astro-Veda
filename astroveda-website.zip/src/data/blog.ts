export interface BlogPost {
  slug: string;
  title: string;
  category: "Astrology" | "Numerology" | "Vastu";
  excerpt: string;
  content: string[];
  date: string;
  readMins: number;
  emoji: string;
}

export const categories = ["All", "Astrology", "Numerology", "Vastu"] as const;

export const blogPosts: BlogPost[] = [
  {
    slug: "saturn-transit-2026",
    title: "Saturn's 2026 Transit: What It Means for Each Moon Sign",
    category: "Astrology",
    emoji: "🪐",
    date: "2026-05-18",
    readMins: 7,
    excerpt: "Shani changes signs and every rashi feels it differently. Here is a practical, fear-free guide to the next two and a half years.",
    content: [
      "Saturn is the great teacher of the zodiac. When it changes signs, the lessons change too — and for the next two and a half years, a new set of Moon signs enters Sade Sati while another set finally exhales.",
      "Rather than treating this transit with dread, treat it as an audit. Saturn rewards structure: in months where you feel resistance, double down on routine, documentation and patience. The discomfort is usually pointing exactly at the area of life that needs maturing.",
      "For signs entering the first phase of Sade Sati, the theme is letting go of borrowed identities. For those in the peak phase, the theme is responsibility without resentment. For those exiting, consolidation — lock in the habits you built under pressure.",
      "Simple remedies that work for everyone: keep your commitments small and unbreakable, serve elders or those who labour, and light a sesame-oil lamp on Saturday evenings. Saturn responds to consistency far more than to grandeur."
    ]
  },
  {
    slug: "choose-baby-name-numerology",
    title: "How to Choose a Baby Name Using Numerology",
    category: "Numerology",
    emoji: "👶",
    date: "2026-04-30",
    readMins: 5,
    excerpt: "A name is the first gift a child receives. Align it with the birth date and you give them a lifelong tailwind.",
    content: [
      "In numerology, every letter carries a number and every name carries a total vibration. The goal of baby-name selection is harmony between three numbers: the psychic number (birth day), the destiny number (full birth date) and the name number.",
      "Start by reducing the date of birth. A child born on the 14th has psychic number 5 — quick, communicative, restless. The full date gives the destiny number, the life's larger arc.",
      "Now test candidate names. Friendly pairs like 1-9, 3-6 and 5-1 create flow; clashing pairs like 8-4 or 2-8 create friction the child must constantly overcome. A single letter change — Aanya instead of Anya — can shift the total into harmony.",
      "Finally, check the first letter against the birth Nakshatra's recommended syllables. When the sound, the number and the star agree, the name simply fits — and parents always say they can feel it."
    ]
  },
  {
    slug: "vastu-home-office",
    title: "Vastu for Your Home Office: 7 Fixes That Need No Renovation",
    category: "Vastu",
    emoji: "🏠",
    date: "2026-04-12",
    readMins: 6,
    excerpt: "Working from home? Your desk direction may be quietly draining your focus. These seven corrections cost almost nothing.",
    content: [
      "The home office is now where wealth is created, yet most are set up wherever a spare corner existed. Vastu offers simple, physics-of-energy corrections that don't require breaking a single wall.",
      "One: face north or east while working — these directions support clarity and fresh opportunity. Two: keep a solid wall behind your chair, never a window; support behind you translates to support in career.",
      "Three: place the heaviest furniture in the south-west of the room. Four: keep the north-east corner light, clean and clutter-free — a small water feature or a money plant works beautifully here.",
      "Five: avoid working directly under an exposed beam. Six: fix anything broken in the room within a week — broken objects normalise stagnation. Seven: if the room's entrance faces your back, place a small mirror so you can see the door. Awareness is energy."
    ]
  },
  {
    slug: "mangal-dosha-myths",
    title: "Mangal Dosha: Separating Myth from Method",
    category: "Astrology",
    emoji: "🔥",
    date: "2026-03-25",
    readMins: 8,
    excerpt: "Nearly half of all charts are technically 'Manglik'. So why does it cancel out far more often than people fear?",
    content: [
      "Few phrases cause as much wedding-season anxiety as Mangal dosha. Mars in the 1st, 2nd, 4th, 7th, 8th or 12th house from Lagna, Moon or Venus technically creates the dosha — which means close to half of humanity qualifies.",
      "What matchmaking websites rarely explain is the long list of cancellations. Mars in its own sign, in Leo or Aquarius, aspected by Jupiter, or matched against another Manglik chart — each of these substantially neutralises the effect.",
      "The real question a competent astrologer asks is not 'is there a dosha?' but 'what is Mars actually doing in this chart?' A strong Mars in the 7th can mean a passionate, protective spouse rather than conflict.",
      "If a genuine affliction exists, remedies range from Kumbha Vivaha rituals to simple Tuesday observances and Hanuman Chalisa recitation. Fear is never a remedy; understanding is."
    ]
  },
  {
    slug: "mobile-number-numerology",
    title: "Is Your Mobile Number Working Against You?",
    category: "Numerology",
    emoji: "📱",
    date: "2026-03-08",
    readMins: 4,
    excerpt: "You repeat your mobile number more often than your own name. Its vibration matters more than you think.",
    content: [
      "Add every digit of your mobile number and reduce to a single digit. That number is a frequency you broadcast dozens of times a day — on forms, to clients, to strangers.",
      "Totals of 1, 5 and 6 are broadly favourable: leadership, communication and harmony respectively. A total of 8 suits those already in Saturn-friendly professions like law, mining or real estate, but can feel heavy for others.",
      "Business owners should also check the last four digits, the part people actually remember. A memorable, harmonious ending like 5151 or 1166 compounds the effect.",
      "Changing a number is easy; choosing the right one is the skill. Match the total to your life path number, avoid your enemy numbers, and keep at least one 5 in the sequence for flowing communication."
    ]
  },
  {
    slug: "plot-selection-vastu",
    title: "Buying Land? Read This Before You Pay the Token",
    category: "Vastu",
    emoji: "📐",
    date: "2026-02-20",
    readMins: 6,
    excerpt: "A plot's shape, slope and surroundings decide 50% of its Vastu before a single brick is laid.",
    content: [
      "Remedying a badly chosen plot costs lakhs; choosing well costs nothing but attention. Begin with shape — square and rectangular plots (ratio under 1:2) hold energy evenly. Avoid triangular and irregular cuts.",
      "Slope tells you where water, and therefore prosperity, flows. The ideal plot slopes gently toward the north-east and rises toward the south-west. A road on the north or east side is a quiet, lifelong advantage.",
      "Check the surroundings within 100 metres: a temple directly opposite the gate, a T-junction hitting the plot, or high-tension lines overhead each create persistent disturbances that no interior fix fully resolves.",
      "Finally, test the soil: it should smell sweet and feel firm. Traditional texts even prescribe a simple pit test — dig, refill, and see if soil remains. Surplus soil signals a prosperous site."
    ]
  },
  {
    slug: "jupiter-return-career",
    title: "The Jupiter Return: Your 12-Year Career Reset Button",
    category: "Astrology",
    emoji: "🌟",
    date: "2026-02-02",
    readMins: 5,
    excerpt: "Every 12 years Jupiter returns to its birth position — and careers visibly bend at ages 24, 36 and 48.",
    content: [
      "Jupiter takes roughly twelve years to circle the zodiac. When it returns to the sign it occupied at your birth, a growth chapter opens: think of ages 24, 36, 48 and 60 as natural promotion windows.",
      "The year before a Jupiter return often feels like outgrowing your container — restlessness, a sense that the current role is too small. That is preparation, not failure.",
      "To use the return well, expand deliberately: take the certification, pitch the bigger client, relocate if the chart supports it. Jupiter rewards optimistic action taken in good faith.",
      "Cross-check your Vimshottari dasha: a Jupiter return inside a favourable dasha is rocket fuel; inside a Saturn period it still delivers, but through patient, structural wins rather than overnight leaps."
    ]
  },
  {
    slug: "business-name-vibration",
    title: "Why Some Brand Names Just 'Click': The Numerology of Naming",
    category: "Numerology",
    emoji: "🏢",
    date: "2026-01-15",
    readMins: 6,
    excerpt: "From iconic 33s to powerhouse 8s, brand name numbers follow patterns that founders ignore at their cost.",
    content: [
      "Look at enduring brands and patterns emerge: name totals of 1 (innovation), 3 (expression), 5 (mass communication) and 6 (luxury and care) dominate consumer markets.",
      "A brand name should harmonise with the founder's destiny number and the industry's natural number. A wellness brand thrives on 6; a logistics company on 5; a bank on disciplined 8 — provided the founder's chart can carry Saturn's weight.",
      "Spelling tweaks are the numerologist's scalpel. Doubling a letter or adding a silent vowel can move a clashing 4 to a magnetic 5 without changing pronunciation.",
      "Before printing the signage, also check the registration date of the company. Launching a 5-name on a 5-date in a Mercury hora stacks three layers of the same supportive frequency."
    ]
  },
  {
    slug: "kitchen-vastu-guide",
    title: "The Kitchen Is Your Home's Engine: A Complete Vastu Guide",
    category: "Vastu",
    emoji: "🍳",
    date: "2025-12-28",
    readMins: 7,
    excerpt: "Agni governs health and wealth alike. Here's how to place the stove, sink and stores so the engine runs clean.",
    content: [
      "In Vastu, the kitchen is the seat of Agni — the fire element that digests not just food but the household's fortunes. The south-east corner is its natural home; north-west is the workable second choice.",
      "The golden rule inside the kitchen: fire and water must not face each other. Keep the stove and the sink on different walls, or separate them with a small wooden barrier if the layout is fixed.",
      "The cook should face east while cooking — it aligns the body's receptive side with the rising sun and, practically, with better morning light. Store grains and heavier provisions in the south-west of the kitchen.",
      "Colours matter more here than anywhere else: warm yellows, oranges and earthy reds feed Agni; avoid black counters and deep blue walls, which symbolically douse the flame."
    ]
  }
];
