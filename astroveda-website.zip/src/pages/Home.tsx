import { Link, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import SEO from "../components/SEO";
import Reveal from "../components/Reveal";
import { openWhatsApp } from "../lib/whatsapp";
import { astrologyServices, numerologyServices, vastuServices } from "../data/services";
import { packages } from "../data/pricing";
import { blogPosts } from "../data/blog";

const GLYPHS = ["♈", "♉", "♊", "♋", "♌", "♍", "♎", "♏", "♐", "♑", "♒", "♓"];

function ZodiacWheel() {
  return (
    <motion.div
      className="relative mx-auto aspect-square w-full max-w-md"
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.8 }}
      aria-hidden
    >
      <motion.div
        className="absolute inset-0 rounded-full border-2 border-dashed border-gold-400/60"
        animate={{ rotate: 360 }}
        transition={{ duration: 90, repeat: Infinity, ease: "linear" }}
      >
        {GLYPHS.map((g, i) => {
          const angle = (i / 12) * 2 * Math.PI - Math.PI / 2;
          const x = 50 + 46 * Math.cos(angle);
          const y = 50 + 46 * Math.sin(angle);
          return (
            <span
              key={g}
              className="absolute grid h-10 w-10 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full bg-white text-lg text-royal-700 shadow-soft"
              style={{ left: `${x}%`, top: `${y}%` }}
            >
              {g}
            </span>
          );
        })}
      </motion.div>
      <div className="absolute inset-[18%] rounded-full bg-gradient-to-br from-royal-700 via-royal-900 to-ink shadow-lift" />
      <div className="absolute inset-[18%] grid place-items-center rounded-full">
        <div className="text-center text-white">
          <span className="block text-4xl text-gold-300">✦</span>
          <p className="mt-1 font-display text-lg">Janma Kundli</p>
          <p className="text-xs text-white/60">Sidereal • Lahiri</p>
        </div>
      </div>
    </motion.div>
  );
}

const steps = [
  { n: "01", t: "Share birth details", d: "Date, time and place — that's all the cosmos needs." },
  { n: "02", t: "We compute & interpret", d: "Sidereal calculations plus a consultant's trained eye." },
  { n: "03", t: "Receive your roadmap", d: "PDF report, remedies and a call to walk you through it." }
];

const testimonials = [
  { name: "Ritika S., Gurugram", text: "The marriage compatibility report caught a Mangal dosha cancellation two other astrologers missed. We married with full confidence." },
  { name: "Aman V., Indore", text: "Changed one letter in my brand name on their advice. Six months later, our best two quarters ever. Coincidence? I've stopped asking." },
  { name: "Priya & Karthik, Chennai", text: "The home Vastu audit needed zero demolition — just rearrangement. The house finally feels like it breathes." }
];

export default function Home() {
  const navigate = useNavigate();
  const featured = [astrologyServices[0], numerologyServices[1], vastuServices[0], astrologyServices[6]];

  return (
    <main>
      <SEO
        title="AI Powered Astrology, Numerology & Vastu"
        description="Generate your free Vedic Kundli, get numerology corrections and Vastu audits. Book a consultation with AstroVeda's expert astrologers today."
      />

      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="pointer-events-none absolute -right-32 -top-32 h-96 w-96 rounded-full bg-royal-100 blur-3xl" />
        <div className="pointer-events-none absolute -left-24 top-64 h-72 w-72 rounded-full bg-gold-300/30 blur-3xl" />
        <div className="mx-auto grid max-w-7xl items-center gap-12 px-4 py-16 sm:px-6 lg:grid-cols-2 lg:py-24">
          <div>
            <Reveal>
              <p className="eyebrow">Vedic wisdom · Modern precision</p>
            </Reveal>
            <Reveal delay={0.08}>
              <h1 className="h-display mt-3 text-4xl leading-tight sm:text-5xl lg:text-6xl">
                AI Powered <span className="text-royal-700">Astrology</span>, Numerology &{" "}
                <span className="text-gold-600">Vastu</span> Solutions
              </h1>
            </Reveal>
            <Reveal delay={0.16}>
              <p className="mt-5 max-w-xl text-lg text-ink/70">
                Your birth chart computed in seconds, interpreted by consultants with 20+ years of
                practice. Reports, remedies and real conversations — not generic predictions.
              </p>
            </Reveal>
            <Reveal delay={0.24}>
              <div className="mt-8 flex flex-wrap gap-3">
                <button className="btn-gold" onClick={() => navigate("/kundli")}>
                  Generate Kundli
                </button>
                <button className="btn-royal" onClick={() => navigate("/book-consultation")}>
                  Book Consultation
                </button>
                <button
                  className="btn-ghost"
                  onClick={() => openWhatsApp("Hi AstroVeda! I'd like a consultation.")}
                >
                  <span aria-hidden>💬</span> WhatsApp Now
                </button>
              </div>
            </Reveal>
            <Reveal delay={0.32}>
              <div className="mt-10 flex flex-wrap gap-x-8 gap-y-3 text-sm text-ink/60">
                <span><strong className="text-royal-700">12,000+</strong> Kundlis generated</span>
                <span><strong className="text-royal-700">4.9★</strong> average rating</span>
                <span><strong className="text-royal-700">21 yrs</strong> of practice</span>
              </div>
            </Reveal>
          </div>
          <ZodiacWheel />
        </div>
      </section>

      {/* Featured services */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
        <Reveal>
          <p className="eyebrow">What we do</p>
          <h2 className="h-display mt-2 text-3xl sm:text-4xl">Guidance for every question life asks</h2>
        </Reveal>
        <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {featured.map((s, i) => (
            <Reveal key={s.slug} delay={i * 0.06}>
              <motion.div whileHover={{ y: -6 }} className="glass h-full p-6">
                <span className="text-3xl" aria-hidden>{s.icon}</span>
                <h3 className="h-display mt-3 text-lg">{s.title}</h3>
                <p className="mt-2 text-sm text-ink/70">{s.description}</p>
              </motion.div>
            </Reveal>
          ))}
        </div>
        <Reveal delay={0.2}>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link to="/services/astrology" className="btn-ghost !py-2 text-sm">Astrology →</Link>
            <Link to="/services/numerology" className="btn-ghost !py-2 text-sm">Numerology →</Link>
            <Link to="/services/vastu" className="btn-ghost !py-2 text-sm">Vastu →</Link>
          </div>
        </Reveal>
      </section>

      {/* How it works */}
      <section className="bg-royal-50/70 py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <Reveal>
            <p className="eyebrow">How it works</p>
            <h2 className="h-display mt-2 text-3xl sm:text-4xl">Three steps from question to clarity</h2>
          </Reveal>
          <div className="mt-8 grid gap-6 md:grid-cols-3">
            {steps.map((s, i) => (
              <Reveal key={s.n} delay={i * 0.08}>
                <div className="glass h-full p-6">
                  <span className="font-display text-4xl text-gold-500">{s.n}</span>
                  <h3 className="h-display mt-2 text-xl">{s.t}</h3>
                  <p className="mt-2 text-sm text-ink/70">{s.d}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing teaser */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
        <Reveal>
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <p className="eyebrow">Reports & packages</p>
              <h2 className="h-display mt-2 text-3xl sm:text-4xl">Pick the depth you need</h2>
            </div>
            <Link to="/pricing" className="btn-ghost !py-2 text-sm">View all packages →</Link>
          </div>
        </Reveal>
        <div className="mt-8 grid gap-6 md:grid-cols-3">
          {packages.slice(0, 3).map((p, i) => (
            <Reveal key={p.id} delay={i * 0.07}>
              <div className={`glass h-full p-6 ${p.popular ? "ring-2 ring-gold-400" : ""}`}>
                {p.popular && (
                  <span className="rounded-full bg-gold-500 px-3 py-1 text-xs font-bold text-ink">
                    Most popular
                  </span>
                )}
                <h3 className="h-display mt-3 text-xl">{p.name}</h3>
                <p className="mt-1 text-sm text-ink/60">{p.tagline}</p>
                <p className="mt-3 font-display text-3xl text-royal-700">
                  ₹{p.price.toLocaleString("en-IN")}
                </p>
                <Link to="/pricing" className="btn-royal mt-5 !py-2 text-sm">Buy now</Link>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      {/* Testimonials */}
      <section className="bg-royal-900 py-16 text-white">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <Reveal>
            <p className="eyebrow !text-gold-300">Stories</p>
            <h2 className="h-display mt-2 text-3xl sm:text-4xl">What seekers say</h2>
          </Reveal>
          <div className="mt-8 grid gap-6 md:grid-cols-3">
            {testimonials.map((t, i) => (
              <Reveal key={t.name} delay={i * 0.08}>
                <figure className="h-full rounded-3xl border border-white/10 bg-white/5 p-6 backdrop-blur">
                  <span className="text-gold-300" aria-hidden>★★★★★</span>
                  <blockquote className="mt-3 text-sm text-white/85">“{t.text}”</blockquote>
                  <figcaption className="mt-4 text-xs font-bold text-gold-300">{t.name}</figcaption>
                </figure>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* Blog teaser */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
        <Reveal>
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <p className="eyebrow">From the journal</p>
              <h2 className="h-display mt-2 text-3xl sm:text-4xl">Latest insights</h2>
            </div>
            <Link to="/blog" className="btn-ghost !py-2 text-sm">All articles →</Link>
          </div>
        </Reveal>
        <div className="mt-8 grid gap-6 md:grid-cols-3">
          {blogPosts.slice(0, 3).map((p, i) => (
            <Reveal key={p.slug} delay={i * 0.07}>
              <Link to={`/blog/${p.slug}`} className="glass block h-full p-6 transition hover:shadow-lift">
                <span className="text-3xl" aria-hidden>{p.emoji}</span>
                <p className="mt-3 text-xs font-bold uppercase tracking-widest text-gold-600">{p.category}</p>
                <h3 className="h-display mt-1 text-lg">{p.title}</h3>
                <p className="mt-2 text-sm text-ink/60">{p.excerpt}</p>
              </Link>
            </Reveal>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="mx-auto max-w-5xl px-4 sm:px-6">
        <Reveal>
          <div className="glass overflow-hidden p-8 text-center sm:p-12">
            <h2 className="h-display text-3xl sm:text-4xl">Your chart already knows. Ask it.</h2>
            <p className="mx-auto mt-3 max-w-xl text-ink/70">
              Generate a free Kundli in under a minute, or talk to a consultant about what you're facing.
            </p>
            <div className="mt-6 flex flex-wrap justify-center gap-3">
              <Link to="/kundli" className="btn-gold">Generate free Kundli</Link>
              <Link to="/book-consultation" className="btn-royal">Book consultation</Link>
            </div>
          </div>
        </Reveal>
      </section>
    </main>
  );
}
