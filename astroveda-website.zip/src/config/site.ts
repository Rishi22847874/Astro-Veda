export const site = {
  name: "AstroVeda",
  tagline: "AI Powered Astrology, Numerology & Vastu Solutions",
  url: import.meta.env.VITE_SITE_URL || "https://astroveda.in",
  whatsapp: import.meta.env.VITE_WHATSAPP_NUMBER || "919999999999",
  phone: import.meta.env.VITE_PHONE_NUMBER || "+919999999999",
  email: import.meta.env.VITE_BUSINESS_EMAIL || "consult@astroveda.in",
  address: "C-12, Hauz Khas, New Delhi 110016, India",
  mapQuery: "Hauz Khas, New Delhi",
  adminPassword: import.meta.env.VITE_ADMIN_PASSWORD || "astroveda@admin",
  razorpayKey: import.meta.env.VITE_RAZORPAY_KEY_ID || "",
  social: {
    instagram: "https://instagram.com/astroveda",
    facebook: "https://facebook.com/astroveda",
    youtube: "https://youtube.com/@astroveda",
    x: "https://x.com/astroveda"
  }
};
