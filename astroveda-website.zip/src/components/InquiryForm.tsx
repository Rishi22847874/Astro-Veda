import { useState } from "react";
import { useForm } from "react-hook-form";
import { Dialog, DialogContent, TextField, MenuItem, CircularProgress } from "@mui/material";
import { saveRecord } from "../lib/storage";
import { emailAdmin, emailUser } from "../lib/email";
import { openWhatsApp } from "../lib/whatsapp";
import { useToast } from "../context/ToastContext";

export interface InquiryFormValues {
  name: string;
  email: string;
  phone: string;
  service: string;
  message: string;
}

interface InquiryFormProps {
  source: string; // e.g. "astrology", "vastu"
  services: string[];
  defaultService?: string;
  compact?: boolean;
  onDone?: () => void;
}

export function InquiryForm({ source, services, defaultService, compact, onDone }: InquiryFormProps) {
  const { toast } = useToast();
  const [submitting, setSubmitting] = useState(false);
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors }
  } = useForm<InquiryFormValues>({
    defaultValues: { service: defaultService || services[0], name: "", email: "", phone: "", message: "" }
  });

  const onSubmit = async (values: InquiryFormValues) => {
    setSubmitting(true);
    try {
      await saveRecord("leads", { ...values, source, type: "inquiry" });
      emailUser({
        to_email: values.email,
        to_name: values.name,
        subject: `We received your ${values.service} enquiry`,
        message: `Namaste ${values.name},\n\nThank you for your interest in ${values.service}. Our consultant will reach you on ${values.phone} within 24 hours.\n\n— Team AstroVeda`
      });
      emailAdmin({
        subject: `New ${source} lead: ${values.service}`,
        message: `Name: ${values.name}\nEmail: ${values.email}\nPhone: ${values.phone}\nService: ${values.service}\nMessage: ${values.message}`
      });
      toast("Enquiry sent! We'll contact you within 24 hours.");
      reset();
      onDone?.();
    } catch {
      toast("Something went wrong while saving your enquiry. Please try again.", "error");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} noValidate className="grid gap-4">
      <div className={`grid gap-4 ${compact ? "" : "sm:grid-cols-2"}`}>
        <TextField
          label="Full name"
          fullWidth
          error={!!errors.name}
          helperText={errors.name?.message}
          {...register("name", {
            required: "Please enter your name",
            minLength: { value: 2, message: "Name looks too short" }
          })}
        />
        <TextField
          label="Phone (WhatsApp)"
          fullWidth
          error={!!errors.phone}
          helperText={errors.phone?.message}
          {...register("phone", {
            required: "Phone number is required",
            pattern: { value: /^[+]?[0-9 -]{10,14}$/, message: "Enter a valid 10-digit phone number" }
          })}
        />
      </div>
      <div className={`grid gap-4 ${compact ? "" : "sm:grid-cols-2"}`}>
        <TextField
          label="Email"
          type="email"
          fullWidth
          error={!!errors.email}
          helperText={errors.email?.message}
          {...register("email", {
            required: "Email is required",
            pattern: { value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/, message: "Enter a valid email address" }
          })}
        />
        <TextField
          label="Service"
          select
          fullWidth
          defaultValue={defaultService || services[0]}
          error={!!errors.service}
          helperText={errors.service?.message}
          {...register("service", { required: "Choose a service" })}
        >
          {services.map((s) => (
            <MenuItem key={s} value={s}>
              {s}
            </MenuItem>
          ))}
        </TextField>
      </div>
      <TextField
        label="Tell us about your requirement"
        multiline
        minRows={3}
        fullWidth
        error={!!errors.message}
        helperText={errors.message?.message}
        {...register("message", { required: "A short message helps us prepare" })}
      />
      <div className="flex flex-wrap gap-3">
        <button type="submit" className="btn-royal" disabled={submitting}>
          {submitting ? <CircularProgress size={18} color="inherit" /> : null}
          {submitting ? "Sending…" : "Send enquiry"}
        </button>
        <button
          type="button"
          className="btn-ghost"
          onClick={() => openWhatsApp(`Hi AstroVeda! I'd like to enquire about ${defaultService || source} services.`)}
        >
          Enquire on WhatsApp
        </button>
      </div>
    </form>
  );
}

/** Modal wrapper used by service cards. */
export function InquiryDialog({
  open,
  onClose,
  source,
  services,
  defaultService
}: {
  open: boolean;
  onClose: () => void;
  source: string;
  services: string[];
  defaultService?: string;
}) {
  return (
    <Dialog open={open} onClose={onClose} fullWidth maxWidth="sm" PaperProps={{ sx: { borderRadius: 6, p: 1 } }}>
      <DialogContent>
        <p className="eyebrow">Enquiry</p>
        <h2 className="h-display mb-4 mt-1 text-2xl">{defaultService || "Tell us what you need"}</h2>
        <InquiryForm
          source={source}
          services={services}
          defaultService={defaultService}
          compact
          onDone={onClose}
        />
      </DialogContent>
    </Dialog>
  );
}
