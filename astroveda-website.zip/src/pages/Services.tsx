import { Link } from "react-router-dom";
import SEO from "../components/SEO";
import Reveal from "../components/Reveal";
import { astrologyServices, numerologyServices, vastuServices } from "../data/services";

const groups = [
  { to: "/services/astrology", title: "Astrology", emoji: "🪐", desc: "Birth charts, horoscopes, compatibility, dashas and remedies.", items: astrologyServices },
  { to: "/services/numerology", title: "Numerology", emoji: "🔢", desc: "Names, numbers and signatures tuned to your birth vibration.", items: numerologyServices },
  { to: "/services/vastu", title: "Vastu", emoji: "🏠", desc: "Homes, offices, factories and plots — audited and harmonised.", items: vastuServices }
];

export default function Services() {
  return (
    <main>
      <SEO
        title="Services"
        description="Explore AstroVeda's astrology, numerology and Vastu services — from birth chart analysis to factory Vastu audits."
      />
      <section className="mx-auto max-w-7xl px-4 pt-14 sm:px-6">
        <Reveal>
          <p className="eyebrow">Services</p>
          <h1 className="h-display mt-2 text-4xl sm:text-5xl">Three sciences, one goal: your clarity</h1>
        </Reveal>
      </section>
      <section className="mx-auto max-w-7xl px-4 py-12 sm:px-6">
        <div className="grid gap-8 lg:grid-cols-3">
          {groups.map((g, i) => (
            <Reveal key={g.to} delay={i * 0.08}>
              <div className="glass flex h-full flex-col p-7">
                <span className="text-4xl" aria-hidden>{g.emoji}</span>
                <h2 className="h-display mt-3 text-2xl">{g.title}</h2>
                <p className="mt-2 text-sm text-ink/70">{g.desc}</p>
                <ul className="mt-4 flex-1 space-y-1.5 text-sm text-ink/80">
                  {g.items.slice(0, 5).map((s) => (
                    <li key={s.slug} className="flex gap-2">
                      <span className="text-gold-500" aria-hidden>✦</span> {s.title}
                    </li>
                  ))}
                  {g.items.length > 5 && <li className="text-ink/50">+ {g.items.length - 5} more</li>}
                </ul>
                <Link to={g.to} className="btn-royal mt-6 !py-2 text-sm">Explore {g.title}</Link>
              </div>
            </Reveal>
          ))}
        </div>
      </section>
    </main>
  );
}
