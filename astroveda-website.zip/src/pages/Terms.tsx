import SEO from "../components/SEO";
import Reveal from "../components/Reveal";
import { site } from "../config/site";

const sections: { h: string; p: string[] }[] = [
  {
    h: "1. Nature of Services",
    p: [
      "AstroVeda provides astrology, numerology and Vastu consultations, reports and remedies based on classical Vedic principles. These services are intended for guidance, self-reflection and spiritual wellbeing.",
      "Our guidance is not a substitute for professional medical, legal, psychological or financial advice. For matters of health, law or finance, always consult a qualified professional."
    ]
  },
  {
    h: "2. No Guarantee of Outcomes",
    p: [
      "Astrological and Vastu interpretations are predictive and advisory in nature. While we apply rigorous classical methodology, we cannot and do not guarantee specific outcomes, results or events in your life. Decisions you take based on our guidance are your own responsibility."
    ]
  },
  {
    h: "3. Accuracy of Birth Details",
    p: [
      "Kundli and prediction accuracy depends entirely on the correctness of the birth date, time and place you provide. AstroVeda is not responsible for inaccuracies arising from incorrect inputs. One-time corrections within 48 hours of report delivery are honoured free of charge."
    ]
  },
  {
    h: "4. Bookings & Rescheduling",
    p: [
      "Consultation slots are confirmed after payment. You may reschedule once, free of charge, up to 12 hours before your slot by contacting us on WhatsApp or email. Missed appointments without notice are treated as consumed."
    ]
  },
  {
    h: "5. Payments, Refunds & Cancellations",
    p: [
      "All prices are listed in Indian Rupees (INR) and processed securely via Razorpay. A full refund is available if you cancel at least 24 hours before your scheduled consultation, or if we fail to deliver your report within the promised time.",
      "Once a consultation has been delivered or a personalised report has been prepared, fees are non-refundable, as the work involved is bespoke to your chart. Approved refunds are processed to the original payment method within 5–7 working days."
    ]
  },
  {
    h: "6. Intellectual Property",
    p: [
      "All reports, content, articles, designs and the AstroVeda name are the intellectual property of AstroVeda. Reports are licensed to you for personal use; commercial redistribution or resale is prohibited."
    ]
  },
  {
    h: "7. Acceptable Use",
    p: [
      "You agree not to misuse the website — including attempting to disrupt the service, scrape content at scale, submit false payment information, or impersonate another person."
    ]
  },
  {
    h: "8. Limitation of Liability",
    p: [
      "To the maximum extent permitted by law, AstroVeda's total liability for any claim arising from our services is limited to the amount you paid for the specific service in question."
    ]
  },
  {
    h: "9. Governing Law",
    p: [
      "These terms are governed by the laws of India. Any disputes shall be subject to the exclusive jurisdiction of the courts of New Delhi."
    ]
  },
  {
    h: "10. Contact",
    p: [
      "For any questions about these terms, write to us at the email address below."
    ]
  }
];

export default function Terms() {
  return (
    <main className="bg-gradient-to-b from-royal-50 to-white pt-28 pb-24">
      <SEO
        title="Terms & Conditions"
        description="Terms of service for AstroVeda's astrology, numerology and Vastu consultations — bookings, refunds, disclaimers and more."
      />
      <div className="mx-auto max-w-3xl px-4">
        <Reveal>
          <p className="eyebrow">Legal</p>
          <h1 className="font-display text-4xl text-ink mt-3">Terms & Conditions</h1>
          <p className="mt-3 text-sm text-ink/55">Last updated: 1 June 2026</p>
          <p className="mt-6 text-ink/75 leading-7">
            By using {site.name} or purchasing any of our services, you agree to the terms below.
            Please read them carefully.
          </p>
        </Reveal>

        <div className="mt-10 space-y-8">
          {sections.map((s, i) => (
            <Reveal key={s.h} delay={Math.min(i * 0.04, 0.2)}>
              <h2 className="font-display text-xl text-ink">{s.h}</h2>
              {s.p.map((para, j) => (
                <p key={j} className="mt-2 text-ink/75 leading-7 text-[0.97rem]">{para}</p>
              ))}
            </Reveal>
          ))}
        </div>

        <Reveal delay={0.1} className="mt-12 rounded-2xl bg-royal-50 border border-royal-100 p-6 text-sm text-ink/75">
          Questions? Email{" "}
          <a href={`mailto:${site.email}`} className="text-royal-700 font-semibold hover:underline">{site.email}</a>.
        </Reveal>
      </div>
    </main>
  );
}
