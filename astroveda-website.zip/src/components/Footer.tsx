import { Link } from "react-router-dom";
import { site } from "../config/site";
import { whatsappLink } from "../lib/whatsapp";

const quickLinks = [
  { to: "/about", label: "About Us" },
  { to: "/kundli", label: "Kundli Generator" },
  { to: "/book-consultation", label: "Book Consultation" },
  { to: "/pricing", label: "Pricing" },
  { to: "/blog", label: "Blog" },
  { to: "/privacy-policy", label: "Privacy Policy" },
  { to: "/terms", label: "Terms & Conditions" }
];

const serviceLinks = [
  { to: "/services/astrology", label: "Astrology" },
  { to: "/services/numerology", label: "Numerology" },
  { to: "/services/vastu", label: "Vastu" },
  { to: "/services", label: "All Services" }
];

export default function Footer() {
  return (
    <footer className="mt-24 bg-royal-900 text-white">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-14 sm:px-6 md:grid-cols-2 lg:grid-cols-4">
        <div>
          <p className="font-display text-2xl">
            Astro<span className="text-gold-300">Veda</span>
          </p>
          <p className="mt-3 max-w-xs text-sm text-white/70">
            Vedic wisdom, modern delivery. Astrology, numerology and Vastu guidance trusted by 12,000+
            families and founders.
          </p>
          <div className="mt-5 flex gap-3">
            {(
              [
                ["Instagram", site.social.instagram, "📸"],
                ["Facebook", site.social.facebook, "👍"],
                ["YouTube", site.social.youtube, "▶️"],
                ["X", site.social.x, "𝕏"]
              ] as const
            ).map(([label, href, glyph]) => (
              <a
                key={label}
                href={href}
                target="_blank"
                rel="noopener noreferrer"
                aria-label={label}
                className="grid h-10 w-10 place-items-center rounded-full bg-white/10 transition hover:bg-gold-500 hover:text-ink"
              >
                <span aria-hidden>{glyph}</span>
              </a>
            ))}
          </div>
        </div>

        <nav aria-label="Quick links">
          <p className="mb-4 font-display text-lg text-gold-300">Quick Links</p>
          <ul className="space-y-2 text-sm">
            {quickLinks.map((l) => (
              <li key={l.to}>
                <Link className="text-white/75 transition hover:text-gold-300" to={l.to}>
                  {l.label}
                </Link>
              </li>
            ))}
          </ul>
        </nav>

        <nav aria-label="Services">
          <p className="mb-4 font-display text-lg text-gold-300">Services</p>
          <ul className="space-y-2 text-sm">
            {serviceLinks.map((l) => (
              <li key={l.to}>
                <Link className="text-white/75 transition hover:text-gold-300" to={l.to}>
                  {l.label}
                </Link>
              </li>
            ))}
          </ul>
        </nav>

        <div>
          <p className="mb-4 font-display text-lg text-gold-300">Contact</p>
          <ul className="space-y-3 text-sm text-white/75">
            <li>{site.address}</li>
            <li>
              <a className="hover:text-gold-300" href={`tel:${site.phone}`}>
                {site.phone}
              </a>
            </li>
            <li>
              <a className="hover:text-gold-300" href={`mailto:${site.email}`}>
                {site.email}
              </a>
            </li>
            <li>
              <a
                className="hover:text-gold-300"
                href={whatsappLink("Hi AstroVeda! I have a question.")}
                target="_blank"
                rel="noopener noreferrer"
              >
                WhatsApp us
              </a>
            </li>
          </ul>
        </div>
      </div>
      <div className="border-t border-white/10 py-5 text-center text-xs text-white/50">
        © {new Date().getFullYear()} {site.name}. All rights reserved. •{" "}
        <Link to="/privacy-policy" className="hover:text-gold-300">Privacy</Link> •{" "}
        <Link to="/terms" className="hover:text-gold-300">Terms</Link>
      </div>
    </footer>
  );
}
