export interface ServiceItem {
  slug: string;
  title: string;
  description: string;
  icon: string; // emoji glyph used in cards
}

export const astrologyServices: ServiceItem[] = [
  { slug: "birth-chart", title: "Birth Chart Analysis", icon: "🪐", description: "A complete house-by-house reading of your Janma Kundli covering personality, strengths and karmic patterns." },
  { slug: "daily-horoscope", title: "Daily Horoscope", icon: "🌅", description: "Personalised daily predictions based on your Moon sign and current planetary transits." },
  { slug: "weekly-horoscope", title: "Weekly Horoscope", icon: "📅", description: "A week-ahead outlook for career, relationships, health and finances." },
  { slug: "yearly-horoscope", title: "Yearly Horoscope", icon: "🗓️", description: "Varshaphal-based annual forecast with month-wise highlights and cautions." },
  { slug: "career-guidance", title: "Career Guidance", icon: "💼", description: "Identify the right profession, job-change windows and promotion periods from your 10th house and dashas." },
  { slug: "business-guidance", title: "Business Guidance", icon: "📈", description: "Muhurta for launches, partnership compatibility and growth periods for entrepreneurs." },
  { slug: "marriage-compatibility", title: "Marriage Compatibility", icon: "💍", description: "Ashtakoota Guna Milan with Mangal dosha analysis for prospective matches." },
  { slug: "transit-analysis", title: "Transit Analysis", icon: "🔭", description: "How Saturn, Jupiter and Rahu-Ketu transits are shaping your current phase." },
  { slug: "dasha-analysis", title: "Dasha Analysis", icon: "⏳", description: "Vimshottari Mahadasha and Antardasha timeline with event predictions." },
  { slug: "gemstone", title: "Gemstone Recommendations", icon: "💎", description: "The right gemstone, weight, metal and wearing muhurta for your chart." }
];

export const numerologyServices: ServiceItem[] = [
  { slug: "name-numerology", title: "Name Numerology", icon: "🔤", description: "Discover the vibration of your name and how it aligns with your life path number." },
  { slug: "name-correction", title: "Name Correction", icon: "✍️", description: "Subtle spelling adjustments that bring your name number into harmony with your birth numbers." },
  { slug: "business-name", title: "Business Name Numerology", icon: "🏢", description: "Choose or correct a brand name whose number supports growth and goodwill." },
  { slug: "mobile-analysis", title: "Mobile Number Analysis", icon: "📱", description: "Check whether your mobile number's total supports your goals — and find a better one." },
  { slug: "vehicle-number", title: "Vehicle Number Suggestions", icon: "🚗", description: "Lucky registration number combinations matched to your birth chart." },
  { slug: "signature-analysis", title: "Signature Analysis", icon: "🖊️", description: "Graphology-based review of your signature with corrections for confidence and luck." }
];

export const vastuServices: ServiceItem[] = [
  { slug: "home-vastu", title: "Home Vastu", icon: "🏠", description: "Room-by-room audit of your home with practical, no-demolition remedies." },
  { slug: "office-vastu", title: "Office Vastu", icon: "🏬", description: "Seating, cabin and entrance corrections that improve focus, cash flow and teamwork." },
  { slug: "commercial-vastu", title: "Commercial Vastu", icon: "🏪", description: "Showroom and retail layouts that draw footfall and conversions." },
  { slug: "factory-vastu", title: "Factory Vastu", icon: "🏭", description: "Machinery placement, raw-material storage and labour-block planning for industry." },
  { slug: "plot-selection", title: "Plot Selection", icon: "📐", description: "Soil, slope, shape and direction analysis before you buy land." }
];
