import { useEffect, useState } from "react";
import { Link, NavLink, useNavigate } from "react-router-dom";
import { AnimatePresence, motion } from "framer-motion";
import { IconButton, Drawer } from "@mui/material";
import MenuRoundedIcon from "@mui/icons-material/MenuRounded";
import CloseRoundedIcon from "@mui/icons-material/CloseRounded";
import { site } from "../config/site";

const links = [
  { to: "/", label: "Home" },
  { to: "/about", label: "About" },
  { to: "/services", label: "Services" },
  { to: "/kundli", label: "Kundli" },
  { to: "/book-consultation", label: "Consultation" },
  { to: "/pricing", label: "Pricing" },
  { to: "/blog", label: "Blog" },
  { to: "/contact", label: "Contact" }
];

function Logo() {
  return (
    <Link to="/" className="flex items-center gap-2" aria-label={`${site.name} home`}>
      <span className="grid h-10 w-10 place-items-center rounded-full bg-royal-700 text-lg text-gold-300 shadow-soft">
        ✦
      </span>
      <span className="font-display text-2xl tracking-wide text-royal-900">
        Astro<span className="text-gold-600">Veda</span>
      </span>
    </Link>
  );
}

export default function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const navClass = ({ isActive }: { isActive: boolean }) =>
    `rounded-full px-3 py-1.5 text-sm font-semibold transition-colors ${
      isActive ? "bg-royal-100 text-royal-700" : "text-ink/70 hover:text-royal-700"
    }`;

  return (
    <header
      className={`sticky top-0 z-40 transition-all ${
        scrolled ? "bg-white/85 shadow-soft backdrop-blur-xl" : "bg-white/60 backdrop-blur"
      }`}
    >
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-3 sm:px-6">
        <Logo />

        <nav className="hidden items-center gap-1 lg:flex" aria-label="Primary">
          {links.map((l) => (
            <NavLink key={l.to} to={l.to} className={navClass} end={l.to === "/"}>
              {l.label}
            </NavLink>
          ))}
        </nav>

        <div className="hidden items-center gap-2 lg:flex">
          <Link to="/kundli" className="btn-ghost !px-4 !py-2 text-sm">
            Generate Kundli
          </Link>
          <Link to="/book-consultation" className="btn-gold !px-4 !py-2 text-sm">
            Book Consultation
          </Link>
        </div>

        <IconButton
          className="lg:!hidden"
          aria-label="Open menu"
          onClick={() => setOpen(true)}
          sx={{ display: { lg: "none" } }}
        >
          <MenuRoundedIcon sx={{ color: "#4527A0" }} />
        </IconButton>
      </div>

      <Drawer anchor="right" open={open} onClose={() => setOpen(false)}>
        <div className="flex h-full w-72 flex-col bg-white p-5">
          <div className="mb-6 flex items-center justify-between">
            <Logo />
            <IconButton aria-label="Close menu" onClick={() => setOpen(false)}>
              <CloseRoundedIcon />
            </IconButton>
          </div>
          <AnimatePresence>
            <nav className="flex flex-col gap-1" aria-label="Mobile">
              {links.map((l, i) => (
                <motion.div
                  key={l.to}
                  initial={{ opacity: 0, x: 16 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.04 }}
                >
                  <NavLink
                    to={l.to}
                    end={l.to === "/"}
                    onClick={() => setOpen(false)}
                    className={({ isActive }) =>
                      `block rounded-2xl px-4 py-3 font-semibold ${
                        isActive ? "bg-royal-100 text-royal-700" : "text-ink/80 hover:bg-royal-50"
                      }`
                    }
                  >
                    {l.label}
                  </NavLink>
                </motion.div>
              ))}
            </nav>
          </AnimatePresence>
          <div className="mt-auto flex flex-col gap-3 pt-6">
            <button
              className="btn-ghost"
              onClick={() => {
                setOpen(false);
                navigate("/kundli");
              }}
            >
              Generate Kundli
            </button>
            <button
              className="btn-gold"
              onClick={() => {
                setOpen(false);
                navigate("/book-consultation");
              }}
            >
              Book Consultation
            </button>
          </div>
        </div>
      </Drawer>
    </header>
  );
}
