import { useState } from "react";
import { useForm } from "react-hook-form";
import { TextField, MenuItem, CircularProgress } from "@mui/material";
import { motion, AnimatePresence } from "framer-motion";
import SEO from "../components/SEO";
import Reveal from "../components/Reveal";
import { saveRecord } from "../lib/storage";
import { emailAdmin, emailUser } from "../lib/email";
import { openWhatsApp } from "../lib/whatsapp";
import { useToast } from "../context/ToastContext";

const SERVICE_TYPES = [
  "Astrology — Birth Chart Reading",
  "Astrology — Career / Business",
  "Astrology — Marriage Compatibility",
  "Numerology — Name / Business Name",
  "Numerology — Mobile / Vehicle Number",
  "Vastu — Home",
  "Vastu — Office / Commercial",
  "Not sure — recommend for me"
];

const TIME_SLOTS = ["10:00 AM", "11:30 AM", "01:00 PM", "03:00 PM", "04:30 PM", "06:00 PM", "07:30 PM"];

interface BookingValues {
  name: string;
  phone: string;
  email: string;
  service: string;
  date: string;
  time: string;
}

export default function Booking() {
  const { toast } = useToast();
  const [submitting, setSubmitting] = useState(false);
  const [confirmed, setConfirmed] = useState<BookingValues | null>(null);

  const {
    register,
    handleSubmit,
    getValues,
    reset,
    formState: { errors }
  } = useForm<BookingValues>({ defaultValues: { service: SERVICE_TYPES[0], time: TIME_SLOTS[0] } });

  const onSubmit = async (values: BookingValues) => {
    setSubmitting(true);
    try {
      await saveRecord("bookings", { ...values, status: "pending" });
      emailUser({
        to_email: values.email,
        to_name: values.name,
        subject: "Your AstroVeda consultation is booked",
        message: `Namaste ${values.name},\n\nYour consultation is confirmed:\n\nService: ${values.service}\nDate: ${values.date}\nTime: ${values.time}\n\nOur consultant will call you on ${values.phone}. Please keep your birth details handy.\n\n— Team AstroVeda`
      });
      emailAdmin({
        subject: `New booking: ${values.service}`,
        message: `Name: ${values.name}\nPhone: ${values.phone}\nEmail: ${values.email}\nService: ${values.service}\nSlot: ${values.date} ${values.time}`
      });
      setConfirmed(values);
      reset();
      window.scrollTo({ top: 0, behavior: "smooth" });
    } catch {
      toast("We couldn't save the booking. Please try again.", "error");
    } finally {
      setSubmitting(false);
    }
  };

  const whatsappBooking = () => {
    const v = getValues();
    const msg =
      `Hi AstroVeda! I'd like to book a consultation.\n` +
      `Name: ${v.name || "—"}\n` +
      `Service: ${v.service}\n` +
      `Preferred date: ${v.date || "—"}\n` +
      `Preferred time: ${v.time}\n` +
      `Phone: ${v.phone || "—"}`;
    openWhatsApp(msg);
  };

  const minDate = new Date().toISOString().split("T")[0];

  return (
    <main>
      <SEO
        title="Book Consultation"
        description="Book a one-on-one astrology, numerology or Vastu consultation with AstroVeda. Choose your slot, get instant confirmation by email and WhatsApp."
      />

      <section className="mx-auto max-w-7xl px-4 pt-14 sm:px-6">
        <Reveal>
          <p className="eyebrow">One-on-one · Phone or video</p>
          <h1 className="h-display mt-2 text-4xl sm:text-5xl">Book a Consultation</h1>
          <p className="mt-4 max-w-2xl text-ink/70">
            Pick a service and a slot. You'll get an email confirmation immediately, and our consultant
            will call you at the chosen time.
          </p>
        </Reveal>
      </section>

      <AnimatePresence>
        {confirmed && (
          <motion.section
            initial={{ opacity: 0, scale: 0.96 }}
            animate={{ opacity: 1, scale: 1 }}
            className="mx-auto max-w-3xl px-4 pt-8 sm:px-6"
          >
            <div className="glass border-2 border-gold-400 p-6 text-center sm:p-8" role="status">
              <span className="text-4xl" aria-hidden>🎉</span>
              <h2 className="h-display mt-2 text-2xl">Booking confirmed, {confirmed.name}!</h2>
              <p className="mt-2 text-sm text-ink/70">
                {confirmed.service} · {confirmed.date} at {confirmed.time}. A confirmation email is on
                its way to {confirmed.email}.
              </p>
              <button
                className="btn-ghost mt-5 !py-2 text-sm"
                onClick={() => openWhatsApp(`Hi! I just booked: ${confirmed.service} on ${confirmed.date} at ${confirmed.time}. Sharing my birth details here.`)}
              >
                Share birth details on WhatsApp
              </button>
            </div>
          </motion.section>
        )}
      </AnimatePresence>

      <section className="mx-auto max-w-3xl px-4 py-10 sm:px-6">
        <Reveal>
          <form onSubmit={handleSubmit(onSubmit)} noValidate className="glass grid gap-4 p-6 sm:p-8">
            <div className="grid gap-4 sm:grid-cols-2">
              <TextField
                label="Full name"
                fullWidth
                error={!!errors.name}
                helperText={errors.name?.message}
                {...register("name", { required: "Please enter your name", minLength: { value: 2, message: "Name looks too short" } })}
              />
              <TextField
                label="Phone (WhatsApp)"
                fullWidth
                error={!!errors.phone}
                helperText={errors.phone?.message}
                {...register("phone", {
                  required: "Phone number is required",
                  pattern: { value: /^[+]?[0-9 -]{10,14}$/, message: "Enter a valid 10-digit phone number" }
                })}
              />
            </div>
            <TextField
              label="Email"
              type="email"
              fullWidth
              error={!!errors.email}
              helperText={errors.email?.message}
              {...register("email", {
                required: "Email is required",
                pattern: { value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/, message: "Enter a valid email address" }
              })}
            />
            <TextField
              label="Service type"
              select
              fullWidth
              defaultValue={SERVICE_TYPES[0]}
              error={!!errors.service}
              helperText={errors.service?.message}
              {...register("service", { required: "Choose a service" })}
            >
              {SERVICE_TYPES.map((s) => (
                <MenuItem key={s} value={s}>{s}</MenuItem>
              ))}
            </TextField>
            <div className="grid gap-4 sm:grid-cols-2">
              <TextField
                label="Preferred date"
                type="date"
                fullWidth
                InputLabelProps={{ shrink: true }}
                inputProps={{ min: minDate }}
                error={!!errors.date}
                helperText={errors.date?.message}
                {...register("date", {
                  required: "Pick a date",
                  validate: (v) => v >= minDate || "Choose today or a future date"
                })}
              />
              <TextField
                label="Preferred time"
                select
                fullWidth
                defaultValue={TIME_SLOTS[0]}
                error={!!errors.time}
                helperText={errors.time?.message}
                {...register("time", { required: "Pick a slot" })}
              >
                {TIME_SLOTS.map((t) => (
                  <MenuItem key={t} value={t}>{t}</MenuItem>
                ))}
              </TextField>
            </div>
            <div className="mt-2 flex flex-wrap gap-3">
              <button type="submit" className="btn-gold" disabled={submitting}>
                {submitting ? <CircularProgress size={18} color="inherit" /> : null}
                {submitting ? "Booking…" : "Book Consultation"}
              </button>
              <button type="button" className="btn-ghost" onClick={whatsappBooking}>
                <span aria-hidden>💬</span> WhatsApp Booking
              </button>
            </div>
          </form>
        </Reveal>

        <Reveal delay={0.1}>
          <div className="mt-8 grid gap-4 sm:grid-cols-3">
            {[
              ["⏱", "30–60 min", "Unhurried sessions, your questions first"],
              ["🔁", "Free reschedule", "Change your slot up to 6 hours before"],
              ["🔒", "Private", "Birth details never leave our desk"]
            ].map(([icon, t, d]) => (
              <div key={t} className="glass p-5 text-center">
                <span className="text-2xl" aria-hidden>{icon}</span>
                <p className="mt-2 font-bold">{t}</p>
                <p className="mt-1 text-xs text-ink/60">{d}</p>
              </div>
            ))}
          </div>
        </Reveal>
      </section>
    </main>
  );
}
