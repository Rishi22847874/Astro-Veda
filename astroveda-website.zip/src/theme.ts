import { createTheme } from "@mui/material/styles";

/** Material Design 3 inspired theme: deep purple primary, gold secondary. */
export const theme = createTheme({
  palette: {
    mode: "light",
    primary: { main: "#4527A0", light: "#7E57C2", dark: "#311B92" },
    secondary: { main: "#C9A227", light: "#E6C868", dark: "#A8861C" },
    background: { default: "#FFFFFF", paper: "#FFFFFF" },
    text: { primary: "#1C1530" }
  },
  shape: { borderRadius: 16 },
  typography: {
    fontFamily: "'Mulish', system-ui, sans-serif",
    h1: { fontFamily: "'Marcellus', serif" },
    h2: { fontFamily: "'Marcellus', serif" },
    h3: { fontFamily: "'Marcellus', serif" },
    button: { textTransform: "none", fontWeight: 700 }
  },
  components: {
    MuiButton: { styleOverrides: { root: { borderRadius: 999, paddingInline: 22 } } },
    MuiTextField: {
      defaultProps: { size: "small" },
      styleOverrides: { root: { "& .MuiOutlinedInput-root": { borderRadius: 14, background: "rgba(255,255,255,0.8)" } } }
    }
  }
});
