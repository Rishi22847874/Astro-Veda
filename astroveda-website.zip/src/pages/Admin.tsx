import { useEffect, useMemo, useState } from "react";
import { Tabs, Tab } from "@mui/material";
import SEO from "../components/SEO";
import { site } from "../config/site";
import { listRecords, type CollectionName, type StoredRecord } from "../lib/storage";
import { useToast } from "../context/ToastContext";

const TABS: { key: CollectionName; label: string; icon: string }[] = [
  { key: "leads", label: "Leads", icon: "🧲" },
  { key: "bookings", label: "Bookings", icon: "📅" },
  { key: "payments", label: "Payments", icon: "💳" },
  { key: "messages", label: "Messages", icon: "✉️" }
];

const AUTH_KEY = "astroveda_admin_ok";

export default function Admin() {
  const [authed, setAuthed] = useState(() => sessionStorage.getItem(AUTH_KEY) === "1");
  const [password, setPassword] = useState("");
  const { toast } = useToast();

  const login = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === site.adminPassword) {
      sessionStorage.setItem(AUTH_KEY, "1");
      setAuthed(true);
      toast("Welcome back, admin.");
    } else {
      toast("Incorrect password.", "error");
    }
  };

  if (!authed) {
    return (
      <main className="min-h-[80vh] flex items-center justify-center bg-gradient-to-b from-royal-50 to-white pt-24">
        <SEO title="Admin Login" description="AstroVeda admin dashboard login." />
        <form onSubmit={login} className="glass rounded-3xl border border-royal-100 p-8 w-full max-w-sm mx-4">
          <div className="text-center text-4xl">🔐</div>
          <h1 className="font-display text-2xl text-ink text-center mt-3">Admin Dashboard</h1>
          <p className="text-center text-xs text-ink/55 mt-1">Enter the admin password to continue</p>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Password"
            className="input-base w-full mt-6"
            autoFocus
          />
          <button type="submit" className="btn-royal w-full mt-4">Unlock</button>
        </form>
      </main>
    );
  }

  return <Dashboard onLogout={() => { sessionStorage.removeItem(AUTH_KEY); setAuthed(false); }} />;
}

function Dashboard({ onLogout }: { onLogout: () => void }) {
  const [tab, setTab] = useState<CollectionName>("leads");
  const [rows, setRows] = useState<StoredRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [counts, setCounts] = useState<Record<CollectionName, number>>({
    leads: 0, bookings: 0, payments: 0, messages: 0
  });

  useEffect(() => {
    (async () => {
      const all = await Promise.all(TABS.map((t) => listRecords(t.key)));
      setCounts({
        leads: all[0].length, bookings: all[1].length, payments: all[2].length, messages: all[3].length
      });
    })();
  }, []);

  useEffect(() => {
    let alive = true;
    setLoading(true);
    listRecords(tab).then((r) => {
      if (!alive) return;
      setRows(r.sort((a, b) => (b.createdAt || "").localeCompare(a.createdAt || "")));
      setLoading(false);
    });
    return () => { alive = false; };
  }, [tab]);

  const revenue = useMemo(
    () => (tab === "payments" ? rows.reduce((s, r) => s + (Number(r.amount) || 0), 0) : 0),
    [tab, rows]
  );

  const columns = useMemo(() => {
    const keys = new Set<string>();
    rows.forEach((r) =>
      Object.keys(r).forEach((k) => {
        if (!["id", "createdAt"].includes(k)) keys.add(k);
      })
    );
    return Array.from(keys);
  }, [rows]);

  return (
    <main className="min-h-screen bg-royal-50/40 pt-28 pb-20">
      <SEO title="Admin Dashboard" description="Manage AstroVeda leads, bookings, payments and messages." />
      <div className="mx-auto max-w-7xl px-4">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <p className="eyebrow">Admin</p>
            <h1 className="font-display text-3xl text-ink mt-1">Dashboard</h1>
          </div>
          <button onClick={onLogout} className="btn-ghost !py-2 !px-5 text-sm">Log out</button>
        </div>

        {/* Stat cards */}
        <div className="mt-6 grid gap-4 grid-cols-2 lg:grid-cols-4">
          {TABS.map((t) => (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={`rounded-2xl border p-5 text-left transition-shadow hover:shadow-md ${
                tab === t.key ? "bg-royal-800 text-white border-royal-800" : "bg-white border-royal-100"
              }`}
            >
              <div className="text-2xl">{t.icon}</div>
              <div className={`mt-2 text-3xl font-display ${tab === t.key ? "text-gold-400" : "text-royal-800"}`}>
                {counts[t.key]}
              </div>
              <div className={`text-sm ${tab === t.key ? "text-white/75" : "text-ink/60"}`}>{t.label}</div>
            </button>
          ))}
        </div>

        <div className="mt-8 rounded-3xl bg-white border border-royal-100 shadow-sm overflow-hidden">
          <div className="border-b border-royal-100 px-4 flex flex-wrap items-center justify-between gap-2">
            <Tabs value={tab} onChange={(_, v) => setTab(v)} variant="scrollable" allowScrollButtonsMobile>
              {TABS.map((t) => (
                <Tab key={t.key} value={t.key} label={`${t.icon} ${t.label}`} sx={{ textTransform: "none", fontWeight: 600 }} />
              ))}
            </Tabs>
            {tab === "payments" && rows.length > 0 && (
              <div className="text-sm font-semibold text-royal-800 pr-2">
                Total revenue: ₹{revenue.toLocaleString("en-IN")}
              </div>
            )}
          </div>

          {loading ? (
            <div className="p-10 text-center text-ink/50 text-sm">Loading records…</div>
          ) : rows.length === 0 ? (
            <div className="p-14 text-center">
              <div className="text-4xl">🌙</div>
              <p className="mt-3 font-display text-xl text-ink">No {tab} yet</p>
              <p className="mt-1 text-sm text-ink/55">
                New {tab} from the website will appear here automatically.
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-royal-50 text-left text-xs uppercase tracking-wide text-ink/55">
                    <th className="px-4 py-3 whitespace-nowrap">Received</th>
                    {columns.map((c) => (
                      <th key={c} className="px-4 py-3 whitespace-nowrap capitalize">{c.replace(/([A-Z])/g, " $1")}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {rows.map((r) => (
                    <tr key={r.id} className="border-t border-royal-50 hover:bg-royal-50/50 align-top">
                      <td className="px-4 py-3 whitespace-nowrap text-ink/60">
                        {r.createdAt ? new Date(r.createdAt).toLocaleString("en-IN", {
                          day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit"
                        }) : "—"}
                      </td>
                      {columns.map((c) => (
                        <td key={c} className="px-4 py-3 max-w-[260px]">
                          <Cell value={r[c]} field={c} />
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        <p className="mt-4 text-xs text-ink/45">
          Records are loaded from Firebase Firestore when configured, otherwise from this browser's local storage (demo mode).
        </p>
      </div>
    </main>
  );
}

function Cell({ value, field }: { value: any; field: string }) {
  if (value === undefined || value === null || value === "") return <span className="text-ink/30">—</span>;
  if (typeof value === "boolean") return <span>{value ? "Yes" : "No"}</span>;
  if (field === "amount") return <span className="font-semibold text-royal-800">₹{Number(value).toLocaleString("en-IN")}</span>;
  if (field === "email") return <a href={`mailto:${value}`} className="text-royal-700 hover:underline break-all">{String(value)}</a>;
  if (field === "phone") return <a href={`tel:${value}`} className="text-royal-700 hover:underline">{String(value)}</a>;
  const s = typeof value === "object" ? JSON.stringify(value) : String(value);
  return <span className="block whitespace-pre-wrap break-words text-ink/80">{s.length > 160 ? s.slice(0, 160) + "…" : s}</span>;
}
