import { useState } from "react";
import { useForm } from "react-hook-form";
import SEO from "../components/SEO";
import Reveal from "../components/Reveal";
import { site } from "../config/site";
import { saveRecord } from "../lib/storage";
import { emailAdmin, emailUser } from "../lib/email";
import { whatsappLink } from "../lib/whatsapp";
import { useToast } from "../context/ToastContext";

interface ContactForm {
  name: string;
  email: string;
  phone: string;
  subject: string;
  message: string;
}

export default function Contact() {
  const { toast } = useToast();
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);
  const { register, handleSubmit, reset, formState: { errors } } = useForm<ContactForm>();

  const onSubmit = async (data: ContactForm) => {
    setSending(true);
    try {
      await saveRecord("messages", data);
      emailAdmin({
        subject: `New contact message: ${data.subject}`,
        message: `${data.name} (${data.email}, ${data.phone}) wrote:\n\n${data.message}`
      });
      emailUser({
        to_email: data.email,
        to_name: data.name,
        subject: "We received your message — AstroVeda",
        message: `Namaste ${data.name}, thank you for reaching out about "${data.subject}". Our team will reply within a few hours. For anything urgent, message us on WhatsApp.`
      });
      setSent(true);
      reset();
      toast("Message sent! We'll get back to you shortly.");
    } catch {
      toast("Something went wrong. Please try WhatsApp instead.", "error");
    } finally {
      setSending(false);
    }
  };

  return (
    <main>
      <SEO
        title="Contact Us"
        description="Get in touch with AstroVeda — call, WhatsApp, email or visit our New Delhi consultation centre. We reply within hours."
      />

      <section className="bg-gradient-to-b from-royal-50 to-white pt-28 pb-12">
        <div className="mx-auto max-w-6xl px-4 text-center">
          <Reveal>
            <p className="eyebrow">Contact</p>
            <h1 className="font-display text-4xl md:text-5xl text-ink mt-3">
              We're a <span className="text-royal-700">message away</span>
            </h1>
            <p className="mt-4 text-ink/70 max-w-xl mx-auto">
              Questions about a reading, a report, or which package fits you best? Write to us — or
              reach us instantly on WhatsApp.
            </p>
          </Reveal>
        </div>
      </section>

      <section className="pb-24">
        <div className="mx-auto max-w-6xl px-4 grid gap-8 lg:grid-cols-5">
          {/* Form */}
          <Reveal className="lg:col-span-3">
            <div className="glass rounded-3xl border border-royal-100 p-8">
              {sent ? (
                <div className="text-center py-10">
                  <div className="text-5xl">🪷</div>
                  <h2 className="font-display text-2xl text-ink mt-4">Message received!</h2>
                  <p className="mt-2 text-ink/65 text-sm">
                    We typically respond within a few hours during business time (10 AM – 7 PM IST).
                  </p>
                  <button onClick={() => setSent(false)} className="btn-ghost mt-6">Send another message</button>
                </div>
              ) : (
                <form onSubmit={handleSubmit(onSubmit)} className="grid gap-4 sm:grid-cols-2" noValidate>
                  <div>
                    <input
                      className="input-base w-full" placeholder="Full name *"
                      {...register("name", { required: "Name is required", minLength: { value: 2, message: "Too short" } })}
                    />
                    {errors.name && <p className="mt-1 text-xs text-red-600">{errors.name.message}</p>}
                  </div>
                  <div>
                    <input
                      className="input-base w-full" placeholder="Phone (10 digits) *"
                      {...register("phone", {
                        required: "Phone is required",
                        pattern: { value: /^[6-9]\d{9}$/, message: "Enter a valid Indian mobile number" }
                      })}
                    />
                    {errors.phone && <p className="mt-1 text-xs text-red-600">{errors.phone.message}</p>}
                  </div>
                  <div className="sm:col-span-2">
                    <input
                      className="input-base w-full" placeholder="Email *" type="email"
                      {...register("email", {
                        required: "Email is required",
                        pattern: { value: /^[^@\s]+@[^@\s]+\.[^@\s]+$/, message: "Enter a valid email" }
                      })}
                    />
                    {errors.email && <p className="mt-1 text-xs text-red-600">{errors.email.message}</p>}
                  </div>
                  <div className="sm:col-span-2">
                    <input
                      className="input-base w-full" placeholder="Subject *"
                      {...register("subject", { required: "Subject is required" })}
                    />
                    {errors.subject && <p className="mt-1 text-xs text-red-600">{errors.subject.message}</p>}
                  </div>
                  <div className="sm:col-span-2">
                    <textarea
                      className="input-base w-full min-h-[130px] resize-y" placeholder="Your message *"
                      {...register("message", { required: "Message is required", minLength: { value: 10, message: "Please add a few more details" } })}
                    />
                    {errors.message && <p className="mt-1 text-xs text-red-600">{errors.message.message}</p>}
                  </div>
                  <div className="sm:col-span-2">
                    <button type="submit" disabled={sending} className="btn-royal w-full disabled:opacity-60">
                      {sending ? "Sending…" : "Send Message"}
                    </button>
                  </div>
                </form>
              )}
            </div>
          </Reveal>

          {/* Info + map */}
          <Reveal delay={0.1} className="lg:col-span-2">
            <div className="space-y-4">
              <div className="glass rounded-3xl border border-royal-100 p-6 space-y-4">
                <InfoRow icon="📍" label="Visit" value={site.address} />
                <InfoRow icon="✉️" label="Email" value={site.email} href={`mailto:${site.email}`} />
                <InfoRow icon="📞" label="Call" value={site.phone} href={`tel:${site.phone}`} />
                <InfoRow icon="🕉️" label="Hours" value="Mon–Sat · 10 AM – 7 PM IST" />
                <div className="flex gap-3 pt-1">
                  <a
                    href={whatsappLink("Hi AstroVeda! I'd like to know more about your services.")}
                    target="_blank" rel="noreferrer"
                    className="btn-gold flex-1 text-center"
                  >
                    WhatsApp Us
                  </a>
                  <a href={`tel:${site.phone}`} className="btn-ghost flex-1 text-center">Call Now</a>
                </div>
              </div>

              <div className="overflow-hidden rounded-3xl border border-royal-100 shadow-sm">
                <iframe
                  title="AstroVeda location map"
                  src={`https://www.google.com/maps?q=${encodeURIComponent(site.mapQuery)}&output=embed`}
                  className="h-64 w-full"
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                />
              </div>
            </div>
          </Reveal>
        </div>
      </section>
    </main>
  );
}

function InfoRow({ icon, label, value, href }: { icon: string; label: string; value: string; href?: string }) {
  const content = href ? (
    <a href={href} className="text-royal-700 hover:underline underline-offset-4 break-all">{value}</a>
  ) : (
    <span className="text-ink/75">{value}</span>
  );
  return (
    <div className="flex items-start gap-3 text-sm">
      <span className="text-xl leading-none mt-0.5">{icon}</span>
      <div>
        <div className="font-semibold text-ink">{label}</div>
        <div className="mt-0.5">{content}</div>
      </div>
    </div>
  );
}
